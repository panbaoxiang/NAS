var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem={Log[Import["Elevation.mx"][[1]]+1.]};(*{368, 493}, 4km*4km*)
{maskO,maskS}=Block[{a,b},
  {a,b}=Values[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/mask.mx"]];
  {a,b}={Join[Table[1,{6},{Length[a]},{Dimensions[a][[2]]}],Table[a,2]],Join[Table[1,{6},{Length[b]},{Dimensions[b][[2]]}],Table[b,2]]};
  {Transpose[Table[a,{3}]],Transpose[Table[b,{3}]]}];
training=Normal[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/training.mx"]];
validation=Normal[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/validation.mx"]];

vobser=Block[{p,t,reanalysis,norm},
 SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/"];
 p=Normal[Import["P_M.mx"]["data"][[DateDifference[{1981,12,31},{1991,1,1}][[1]];;DateDifference[{1981,12,31},{1996,12,31}][[1]]]]];
 t=Normal[Import["T_M.mx"]["data"][[DateDifference[{1981,12,31},{1991,1,1}][[1]];;DateDifference[{1981,12,31},{1996,12,31}][[1]]]]];
 SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis"];
 reanalysis=Flatten[Map[Block[{tempt=Normal[Import[DateString[#,{"Year","_","Month",".mx"}]]["data"]][[1;;-2]]},
	Mean[Table[tempt[[i;;-1;;24]],{i,1,24}]]]&,DateRange[{1991,1,1},{1996,12,1},"Month"]],1];
 norm=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Normalization.mx"]["meanvarobser"];
 reanalysis=Table[(reanalysis[[date,var]]-norm[[var,1]])/(norm[[var,2]]+10^-7),{date,Length[reanalysis]},{var,Dimensions[reanalysis][[2]]}];
 t=Table[(t[[i]]-norm[[-1,1]])/(norm[[-1,2]]+10^-7)*maskO[[-2,1]],{i,Length[t]}];
 p=Log[Map[#*maskO[[-1,1]]&,p]+1.];
 Table[Join[reanalysis[[i]],{t[[i]],p[[i]]}],{i,Length[p]}]];


(*pSR*)
choice1=Block[{pSR,globe,Report},
Print["p_simulation_regularization"];
pSR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/trained_p_simulation_regularization_keep.mx"];
globe=Block[{net=pSR,size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[-1]],{i,Length[data]}];
  corr=Table[If[maskS[[-1,1,j,k]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/corr_p_simulation_regularization.mx",globe]];
	  
(*tSR*)
choice2=Block[{tSR,globe,Report},
Print["t_simulation_regularization"];
tSR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/trained_t_simulation_regularization_keep.mx"];
globe=Block[{net=tSR,size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[7]],{i,Length[data]}];
  corr=Table[If[maskS[[-1,1,j,k]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/corr_t_simulation_regularization.mx",globe]];


(*futureSR*)
choice3=Block[{futureSR,globe,Report},
Print["future_simulation_regularization"];
futureSR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_future_simulation_regularization.mx"];
globe=Block[{net=futureSR,size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,3]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr];
Print[Mean[Select[Flatten[globe],NumberQ]]];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/corr_future_simulation_regularization.mx",globe]];


(*yesterdaySR*)
choice4=Block[{yesterdaySR,globe,Report},
Print["yesterday_simulation_regularization"];
yesterdaySR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_yesterday_simulation_regularization.mx"];
globe=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result,net=yesterdaySR},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,1]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr];
Print[Mean[Select[Flatten[globe],NumberQ]]];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/corr_yesterday_simulation_regularization.mx",globe]];

(*pOR*)
choice5=Block[{pOR,globe,Report},
Print["p_observation_regularization"];
pOR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_p_observation_regularization.mx"];

globe=Block[{data,model,simu,obser,corr,result,net=pOR},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[8]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr];       
Print[Mean[Select[Flatten[globe],NumberQ]]];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/corr_p_observation_regularization.mx",globe]];


(*tOR*)
choice6=Block[{tOR,globe,Report},
Print["t_observation_regularization"];
tOR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_t_observation_regularization.mx"];

globe=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result,net=tOR},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[7]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr];
Print[Mean[Select[Flatten[globe],NumberQ]]];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/corr_t_observation_regularization.mx",globe]];

(*futureOR*)
choice7=Block[{futureOR,globe,Report},
Print["future_observation_regularization"];
futureOR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_future_observation_regularization.mx"];

globe=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result,net=futureOR},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,3]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr];
Print[Mean[Select[Flatten[globe],NumberQ]]];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/corr_future_observation_regularization.mx",globe]];

(*yesterdayOR*)
choice8=Block[{yesterdayOR,globe,Report},
Print["yesterday_observation_regularization"];
yesterdayOR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_yesterday_observation_regularization.mx"];

globe=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result,net=yesterdayOR},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,1]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr];
Print[Mean[Select[Flatten[globe],NumberQ]]];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/corr_yesterday_observation_regularization.mx",globe]];
