channel=8;
day=3;
dim={channel,day,16,22};
dime={4,day,16,22};

contract[channel_,crop_:{{1,1},{1,1}}]:=NetGraph[{"conv"->{ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                                                           ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp},
                                   "pooling"->PoolingLayer[{1,2,2},{1,2,2},{0,1,1}],
                                   "cropping"->PartLayer[{;;,crop[[1,1]];;-crop[[1,-1]],crop[[2,1]];;-crop[[2,-1]]}]},
                         {NetPort["Input"]->"conv"->"pooling"->NetPort["Pooling"],"conv"->"cropping"->NetPort["Shortcut"]}]

ResizeLayer3D[n_, {dimInx_, dimIny_, dimInz_}] :=
 Block[{sc = 2},
  NetChain[{
    FlattenLayer[1, "Input" -> {n sc, dimInx, dimIny, dimInz}],    
    ResizeLayer[{Scaled[sc], Scaled[sc]}],
    ReshapeLayer[{n sc, dimInx, sc dimIny, sc dimInz}],
    TransposeLayer[2 <-> 3],
    FlattenLayer[1],
    ResizeLayer[{Scaled[sc], Scaled[1]}],
    ReshapeLayer[{n sc, sc dimIny, sc dimInx, sc dimInz}],
    TransposeLayer[2 <-> 3],
    ConvolutionLayer[n, 1]}
   ]]

ClearAll[expand];
expand[channel_,{dimInx_, dimIny_, dimInz_},pad_:{1,1,1}]:=NetGraph[
		{"deconv"->{ResizeLayer3D[channel,{dimInx,dimIny,dimInz}],BatchNormalizationLayer[],Ramp,PartLayer[{;;,pad[[1]];;-2,pad[[2]];;-2,pad[[3]];;-2}]},
         "join"->CatenateLayer[],
         "conv"->{ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                  ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp}},
        {NetPort["Input"]->"deconv"->"join",NetPort["Shortcut"]->"join"->"conv"}]

Unet=Block[{dim=dim},
NetInitialize[NetGraph[<|
  "contract_1"->contract[16],
  "contract_2"->contract[32],
  "contract_3"->contract[64],
  "contract_4"->contract[128],
  "ubase"->{ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,DropoutLayer[0.5]},
  "expand_4"->expand[64,{3,2,3},{3,1,2}],
  "expand_3"->expand[32,{3,3,4},{3,1,1}],
  "expand_2"->expand[16,{3,5,7},{3,1,2}],
  "expand_1"->expand[8,{3,9,12},{3,2,2}]|>,
  {NetPort["Input"]->"contract_1",
   NetPort["contract_1","Pooling"]->"contract_2",
   NetPort["contract_2","Pooling"]->"contract_3",
   NetPort["contract_3","Pooling"]->"contract_4",
   NetPort["contract_4","Pooling"]->"ubase",
   "ubase"->NetPort["expand_4","Input"],
   NetPort["contract_4","Shortcut"]->NetPort["expand_4","Shortcut"],
   NetPort["expand_4","Output"]->NetPort["expand_3","Input"],
   NetPort["contract_3","Shortcut"]->NetPort["expand_3","Shortcut"],
   NetPort["expand_3","Output"]->NetPort["expand_2","Input"],
   NetPort["contract_2","Shortcut"]->NetPort["expand_2","Shortcut"],
    NetPort["expand_2","Output"]->NetPort["expand_1","Input"],
   NetPort["contract_1","Shortcut"]->NetPort["expand_1","Shortcut"]},
   "Input"->{10,3,16,22}]]];

pR=Block[{c=8},
NetGraph[<|"part"->PartLayer[1;;6],
           "cat"->CatenateLayer[],
           "u"->Unet,
           "simu"->{ConvolutionLayer[1,{1,1,1}],BatchNormalizationLayer[],Ramp,FlattenLayer[1]},
           "thread"->ThreadingLayer[Times],
           "obser"->PartLayer[c],
           "mpart"->PartLayer[c],
           "mse"->MeanSquaredLossLayer[]|>,
    {NetPort["Elevation"]->"cat",
     NetPort["Input"]->"part"->"cat"->"u"->"simu"->"thread",
     NetPort["Mask"]->"mpart"->"thread"->"mse",
     NetPort["Input"]->"obser"->"mse"},
   "Elevation"->dime,
   "Input"->dim,
   "Mask"->dim]];

tR=Block[{c=7},
NetGraph[<|"part"->PartLayer[1;;6],
           "cat"->CatenateLayer[],
           "u"->Unet,
           "simu"->{ConvolutionLayer[1,{1,1,1}],BatchNormalizationLayer[],FlattenLayer[1]},
           "thread"->ThreadingLayer[Times],
           "obser"->PartLayer[c],
           "mpart"->PartLayer[c],
           "mse"->MeanSquaredLossLayer[]|>,
    {NetPort["Elevation"]->"cat",
     NetPort["Input"]->"part"->"cat"->"u"->"simu"->"thread",
     NetPort["Mask"]->"mpart"->"thread"->"mse",
     NetPort["Input"]->"obser"->"mse"},
   "Elevation"->dime,
   "Input"->dim,
   "Mask"->dim]]

futureR=NetGraph[<|
           "part"->{PartLayer[{All,1;;2}],ConvolutionLayer[6,{2,1,1},"PaddingSize"->{1,0,0}]},
           "cat"->CatenateLayer[],
           "u"->Unet,
           "simu"->{NetMapOperator[ConvolutionLayer[1,{1,1}]],BatchNormalizationLayer[],FlattenLayer[1]},
           "thread"->ThreadingLayer[Times],
           "mpart"->PartLayer[{All,3}],
           "obser"->PartLayer[{All,3}],
           "mse"->MeanSquaredLossLayer[]|>,
    {NetPort["Elevation"]->"cat",
     NetPort["Input"]->"part"->"cat"->"u"->"simu"->"thread",
     NetPort["Mask"]->"mpart"->"thread"->"mse",
     NetPort["Input"]->"obser"->"mse"},
   "Elevation"->dime,
   "Input"->dim,
   "Mask"->dim];

yesterdayR=NetGraph[<|
           "part"->{PartLayer[{All,2;;3}],ConvolutionLayer[6,{2,1,1},"PaddingSize"->{1,0,0}]},
           "cat"->CatenateLayer[],
           "u"->Unet,
           "simu"->{NetMapOperator[ConvolutionLayer[1,{1,1}]],BatchNormalizationLayer[],FlattenLayer[1]},
           "thread"->ThreadingLayer[Times],
           "mpart"->PartLayer[{All,1}],
           "obser"->PartLayer[{All,1}],
           "mse"->MeanSquaredLossLayer[]|>,
    {NetPort["Elevation"]->"cat",
     NetPort["Input"]->"part"->"cat"->"u"->"simu"->"thread",
     NetPort["Mask"]->"mpart"->"thread"->"mse",
     NetPort["Input"]->"obser"->"mse"},
   "Elevation"->dime,
   "Input"->dim,
   "Mask"->dim];
