existing=Block[{},
 SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/existing"];
 Map["N_"<>#&,FileNames["*mx"]]];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Forecast"];
trainingfile=RandomSample[Flatten[Map[FileNames["N_"<>ToString[#]<>"*"]&,Range[1982,2016]]]];
trainingfile=Select[trainingfile,Not[MemberQ[existing,#]]&];
var=Import[trainingfile[[1]]][[;;,-1]];
dim={25,33};
lat=Import[trainingfile[[1]]][[2]][["lat"]][[4;;19]];
lon=Import[trainingfile[[1]]][[2]][["lon"]][[6;;27]];

training=Table[If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/"<>trainingfile[[i]]]],
Block[{tempt=Import[trainingfile[[i]]][[;;,1]]},
                 Table[Set[tempt[[j]],NumericArray[Map[ArrayResample[#,dim]&,Normal[tempt[[j]]]],"Real32"]],{j,{1,-1}}];
                 tempt=NumericArray[Transpose[Normal[tempt]],"Real32"];
                 Print[trainingfile[[i]]];
                 Print[Dimensions[tempt]];
                 Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/"<>trainingfile[[i]],tempt];
                 {StringSplit[trainingfile[[i]],{"_","."}][[2;;-2]],var,tempt}]],{i,Length[trainingfile]}];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast"];
files=FileNames["N*mx"];
Table[Block[{},
 Print[files[[i]]]; 
 Export[StringSplit[files[[i]],"N_"][[1]],
	<|"data"->Import[files[[i]]][[;;,{2,3,4,5,6,7,8,1},4;;19,6;;27]],
	  "lat"->lat,
	  "lon"->lon,
          "var"->var[[{2,3,4,5,6,7,8,1}]]|>];
 DeleteFile[files[[i]]]],{i,Length[files]}];



SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Reanalysis"];
trainingfile=Flatten[Map[FileNames[ToString[#]<>"*"]&,Range[1982,2018]]];
var=Import[trainingfile[[1]]][[2;;,-1]];
lat=Import[trainingfile[[1]]][[2]][["lat"]][[7;;37]];
lon=Import[trainingfile[[1]]][[2]][["lon"]][[11;;53]];
Table[If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/"<>trainingfile[[i]]]],
Block[{tempt},
 tempt=Import[trainingfile[[i]]][[2;;,1]];
 tempt=Map[#[[;;,7;;37,11;;53]]&,tempt];
 tempt=NumericArray[Transpose[Normal[tempt]],"Real32"];
 Print[trainingfile[[i]]];
 Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/"<>trainingfile[[i]],
	<|"data"->tempt,
          "lat"->lat,
          "lon"->lon,
	  "var"->var|>];]],{i,Length[trainingfile]}];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Observation"];
files=Table["WUS_SWE_P_T_"<>ToString[year]<>".mx",{year,1981,2019}];
lat=Import[files[[1]]]["lat"];
lon=Import[files[[1]]]["lon"]+360.;

p=Table[Import[files[[i]]]["P"],{i,Length[files]}];(*since 1981.10.1*)
p=Flatten[Normal[p],1];
start=DateDifference[{1981,9,30},{1982,1,1}][[1]];
p=p[[start;;]];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/P_H.mx",
  <|"data"->NumericArray[p,"Real32"],
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

(*
latL=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lat"];
lonL=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lon"];
p=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/P_H.mx"]["data"];
pL=Map[ArrayResample[#,{Length[latL],Length[lonL]}]&,p];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/P_L.mx",
  <|"data"->NumericArray[pL,"Real32"],
    "lat"->latL,
    "lon"->lonL,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

latM=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/1985_01.mx"]["lat"];
lonM=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/1985_01.mx"]["lon"];
pM=Map[ArrayResample[#,{Length[latM],Length[lonM]}]&,p];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/P_M.mx",
  <|"data"->NumericArray[pM,"Real32"],
    "lat"->latM,
    "lon"->lonM,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];
*)

t=Table[Import[files[[i]]]["T"],{i,Length[files]}];(*since 1981.10.1*)
t=Flatten[Normal[t],1];
start=DateDifference[{1981,9,30},{1982,1,1}][[1]];
t=t[[start;;]];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/T_H.mx",
  <|"data"->NumericArray[t,"Real32"],
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

(*
latL=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lat"];
lonL=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lon"];
tL=Map[ArrayResample[#,{Length[latL],Length[lonL]}]&,t];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/T_L.mx",
  <|"data"->NumericArray[tL,"Real32"],
    "lat"->latL,
    "lon"->lonL,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

latM=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/1985_01.mx"]["lat"];
lonM=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/1985_01.mx"]["lon"];
tM=Map[ArrayResample[#,{Length[latM],Length[lonM]}]&,t];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/T_M.mx",
  <|"data"->NumericArray[tM,"Real32"],
    "lat"->latM,
    "lon"->lonM,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];
*)

swe=Table[Import[files[[i]]]["SWE"],{i,Length[files]}];(*since 1981.10.1*)
swe=Flatten[Normal[swe],1];
start=DateDifference[{1981,9,30},{1982,1,1}][[1]];
swe=swe[[start;;]];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/SWE_H.mx",
  <|"data"->NumericArray[swe,"Real32"],
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

(tart=DateDifference[{1981,9,30},{1982,1,1}][[1]];
swe=swe[[start;;]];
latL=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lat"];
lonL=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lon"];
sweL=Map[ArrayResample[#,{Length[latL],Length[lonL]}]&,swe];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/SWE_L.mx",
  <|"data"->NumericArray[sweL,"Real32"],
    "lat"->latL,
    "lon"->lonL,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

latM=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/1985_01.mx"]["lat"];
lonM=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/1985_01.mx"]["lon"];
sweM=Map[ArrayResample[#,{Length[latM],Length[lonM]}]&,swe];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/SWE_M.mx",
  <|"data"->NumericArray[sweM,"Real32"],
    "lat"->latM,
    "lon"->lonM,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];
*)

(*
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/"];
files=FileNames["*mx"];
Table[Block[{tempt=Import[files[[i]]]},
 Print["c "<>files[[i]]];
 If[Length[tempt]<4,
	Block[{},
        Print[files[[i]]];
	DeleteFile[files[[i]]]]]],{i,Length[files]}]
*)
