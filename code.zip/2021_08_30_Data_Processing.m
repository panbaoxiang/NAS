existing=Block[{},
 SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/"];
 Map["N_"<>#&,FileNames["*mx"]]];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Forecast"];
trainingfile=RandomSample[Flatten[Map[FileNames["N_"<>ToString[#]<>"*"]&,Range[1982,2019]]]];
trainingfile=Select[trainingfile,Not[MemberQ[existing,#]]&];
var=Import[trainingfile[[1]]][[;;,-1]];
dim={25,33};
lat=Import[trainingfile[[1]]][[2]][["lat"]][[4;;19]];
lon=Import[trainingfile[[1]]][[2]][["lon"]][[6;;27]];

training=Table[If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/"<>trainingfile[[i]]]],
 Block[{tempt=Import[trainingfile[[i]]][[;;,1]]},
                 Table[Set[tempt[[j]],NumericArray[Map[ArrayResample[#,dim]&,Normal[tempt[[j]]]],"Real32"]],{j,{1,-1}}];
                 tempt=NumericArray[Transpose[Normal[tempt]],"Real32"];
                 Print[trainingfile[[i]]];
                 Print[Dimensions[tempt]];
                 Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/"<>trainingfile[[i]],tempt];
                 {StringSplit[trainingfile[[i]],{"_","."}][[2;;-2]],var,tempt}]],{i,Length[trainingfile]}];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast"];
files=FileNames["N*mx"];
Table[Block[{},
 Print[files[[i]]]; 
 Export[StringSplit[files[[i]],"N_"][[1]],
	<|"data"->Import[files[[i]]][[;;,{2,3,4,5,6,7,8,1},4;;19,6;;27]],
	  "lat"->lat,
	  "lon"->lon,
          "var"->var[[{2,3,4,5,6,7,8,1}]]|>];
 DeleteFile[files[[i]]]],{i,Length[files]}];



SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Reanalysis"];
trainingfile=Flatten[Map[FileNames[ToString[#]<>"*"]&,Range[1982,2020]]];
var=Import[trainingfile[[1]]][[2;;,-1]];
lat=Import[trainingfile[[1]]][[2]][["lat"]][[7;;37]];
lon=Import[trainingfile[[1]]][[2]][["lon"]][[11;;53]];
Table[If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/"<>trainingfile[[i]]]],
Block[{tempt},
 tempt=Import[trainingfile[[i]]][[2;;,1]];
 tempt=Map[#[[;;,7;;37,11;;53]]&,tempt];
 tempt=NumericArray[Transpose[Normal[tempt]],"Real32"];
 Print[trainingfile[[i]]];
 Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/"<>trainingfile[[i]],
	<|"data"->tempt,
          "lat"->lat,
          "lon"->lon,
	  "var"->var|>];]],{i,Length[trainingfile]}];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Observation"];
files=Table["WUS_SWE_P_T_"<>ToString[year]<>".mx",{year,1981,2019}];
lat=Import[files[[1]]]["lat"];
lon=Import[files[[1]]]["lon"]+360.;

p=Table[Import[files[[i]]]["P"],{i,Length[files]}];(*since 1981.10.1*)
p=Flatten[Normal[p],1];
start=DateDifference[{1981,9,30},{1982,1,1}][[1]];
p=p[[start;;]];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/P_R5.mx",
  <|"data"->NumericArray[p,"Real32"],
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

t=Table[Import[files[[i]]]["T"],{i,Length[files]}];(*since 1981.10.1*)
t=Flatten[Normal[t],1];
start=DateDifference[{1981,9,30},{1982,1,1}][[1]];
t=t[[start;;]];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/T_R5.mx",
  <|"data"->NumericArray[t,"Real32"],
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];


swe=Table[Import[files[[i]]]["SWE"],{i,Length[files]}];(*since 1981.10.1*)
swe=Flatten[Normal[swe],1];
start=DateDifference[{1981,9,30},{1982,1,1}][[1]];
swe=swe[[start;;]];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/SWE_R5.mx",
  <|"data"->NumericArray[swe,"Real32"],
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];


SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
p=Import["P_R5.mx"]["data"];
t=Import["T_R5.mx"]["data"];

resolution={{16,22},{31,43},{61,82},{184,246},{368,493}};
scale=2;
np=Block[{tempt},
 tempt=Mean[Normal[Flatten[Table[p[[;;,i;;-1;;scale,j;;-2;;scale]],{i,scale},{j,scale}]]]];
 NumericArray[(tempt /. x_ /; x<0->-9999.),"Real32"]];
nt=Block[{tempt},
 tempt=Mean[Normal[Flatten[Table[t[[;;,i;;-1;;scale,j;;-2;;scale]],{i,scale},{j,scale}]]]];
 NumericArray[(tempt /. x_ /; x<-100.->-9999.),"Real32"]];
lat=Range[49,34,(34-49)/183.];
lon=Range[235,256,(256-235)/245.];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/P_R4.mx",
  <|"data"->np,
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/T_R4.mx",
  <|"data"->nt,
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

scale=6;
np=Block[{tempt},
 tempt=Mean[Normal[Flatten[Table[p[[;;,i;;-3;;scale,j;;-2;;scale]],{i,scale},{j,scale}]]]];
 NumericArray[(tempt /. x_ /; x<0->-9999.),"Real32"]];
nt=Block[{tempt},
 tempt=Mean[Normal[Flatten[Table[t[[;;,i;;-3;;scale,j;;-2;;scale]],{i,scale},{j,scale}]]]];
 NumericArray[(tempt /. x_ /; x<-100.->-9999.),"Real32"]];
lat=Range[49,34,(34-49)/60.];
lon=Range[235,256,(256-235)/81.];

Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/P_R3.mx",
  <|"data"->np,
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/T_R3.mx",
  <|"data"->nt,
    "lat"->lat,
    "lon"->lon,
    "date"->"1982.1.1 to 2019.10,1 by day"|>];

Block[{data=p,name="P",size={372,473},target={31,43},scale={12,11},tempt,n,result,thre},
  thre=scale[[1]]*scale[[2]]/3.;
  tempt=ArrayResample[Normal[data],Prepend[size,Length[data]]];
  n=Table[tempt[[;;,(i-1)*scale[[1]]+1;;i*scale[[1]],(j-1)*scale[[2]]+1;;j*scale[[2]]]],{i,target[[1]]},{j,target[[2]]}];
  (*result=Map[Map[Map[Mean[Flatten[#]]&,#]&,#]&,n];*)
  result=Map[Map[Map[Block[{tempt=Select[Flatten[#],#>=0.&]},If[Length[tempt]>thre,Mean[tempt],-9999.]]&,#]&,#]&,n];
  result=Transpose[result,{2,3,1}];
  lat=Range[49,34,-.5];
  lon=Range[235,256,.5];
  Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/"<>name<>"_R2.mx",
  <|"data"->NumericArray[result,"Real32"],
      "lat"->lat,
      "lon"->lon,
      "date"->"1982.1.1 to 2019.10,1 by day"|>]]

Block[{data=t,name="T",size={372,473},target={31,43},scale={12,11},tempt,n,result,thre},
  thre=scale[[1]]*scale[[2]]/3.;
  tempt=ArrayResample[Normal[data],Prepend[size,Length[data]]];
  n=Table[tempt[[;;,(i-1)*scale[[1]]+1;;i*scale[[1]],(j-1)*scale[[2]]+1;;j*scale[[2]]]],{i,target[[1]]},{j,target[[2]]}];
  (*result=Map[Map[Map[Mean[Flatten[#]]&,#]&,#]&,n];*)
  result=Map[Map[Map[Block[{tempt=Select[Flatten[#],#>=-100.&]},If[Length[tempt]>thre,Mean[tempt],-9999.]]&,#]&,#]&,n];
  result=Transpose[result,{2,3,1}];
  lat=Range[49,34,-.5];
  lon=Range[235,256,.5];
  Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/"<>name<>"_R2.mx",
  <|"data"->NumericArray[result,"Real32"],
      "lat"->lat,
      "lon"->lon,
      "date"->"1982.1.1 to 2019.10,1 by day"|>]]

Block[{data=p,name="P",size={368,484},target={16,22},scale={23,22},tempt,n,result,thre},
  thre=scale[[1]]*scale[[2]]/3.;
  tempt=ArrayResample[Normal[data],Prepend[size,Length[data]]];
  n=Table[tempt[[;;,(i-1)*scale[[1]]+1;;i*scale[[1]],(j-1)*scale[[2]]+1;;j*scale[[2]]]],{i,target[[1]]},{j,target[[2]]}];
  (*result=Map[Map[Map[Mean[Flatten[#]]&,#]&,#]&,n];*)
  result=Map[Map[Map[Block[{tempt=Select[Flatten[#],#>=0.&]},If[Length[tempt]>thre,Mean[tempt],-9999.]]&,#]&,#]&,n];
  result=Transpose[result,{2,3,1}];
  lat=Range[49,34,-1];
  lon=Range[235,256,1];
  Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/"<>name<>"_R1.mx",
    <|"data"->NumericArray[result,"Real32"],
      "lat"->lat,
      "lon"->lon,
      "date"->"1982.1.1 to 2019.10,1 by day"|>]]

Block[{data=t,name="T",size={368,484},target={16,22},scale={23,22},tempt,n,result,thre},
  thre=scale[[1]]*scale[[2]]/3.;
  tempt=ArrayResample[Normal[data],Prepend[size,Length[data]]];
  n=Table[tempt[[;;,(i-1)*scale[[1]]+1;;i*scale[[1]],(j-1)*scale[[2]]+1;;j*scale[[2]]]],{i,target[[1]]},{j,target[[2]]}];
  (*result=Map[Map[Map[Mean[Flatten[#]]&,#]&,#]&,n];*)
  result=Map[Map[Map[Block[{tempt=Select[Flatten[#],#>=-100.&]},If[Length[tempt]>thre,Mean[tempt],-9999.]]&,#]&,#]&,n];
  result=Transpose[result,{2,3,1}];
  lat=Range[49,34,-1];
  lon=Range[235,256,1];
  Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/"<>name<>"_R1.mx",
    <|"data"->NumericArray[result,"Real32"],
      "lat"->lat,
      "lon"->lon,
      "date"->"1982.1.1 to 2019.10,1 by day"|>]]


(*
var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
ele=Log[Import["Elevation.mx"][[1]]+1.];(*{368, 493}, 4km*4km*)
meanvarobserH=Import["Normalization.mx"]["meanvarobser_H"];
meanvarobserL=Import["Normalization.mx"]["meanvarobser_L"];
meanvarforecast=Import["Normalization.mx"]["meanvarforecast"];
trainingfile=Flatten[Table[FileNames["Paired/"<>ToString[year]<>"*mx"],{year,1982,1990}]];
validationfile=Flatten[Table[FileNames["Paired/"<>ToString[year]<>"*mx"],{year,1991,1996}]];
testfile=Flatten[Table[FileNames["Paired/"<>ToString[year]<>"*mx"],{year,1997,2016}]];
{maskO,maskS}=Values[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/mask.mx"]];
mask=Block[{tempt=Import[trainingfile[[1]]]["observation"][[;;,-2]],raw,position,tempt2=Import[trainingfile[[1]]]["observation"][[;;,-1]],position2},
 raw=Table[1,{Dimensions[tempt][[2]]},{Dimensions[tempt][[3]]}];
 position=Position[Mean[Normal[tempt]],_?(#<-15&)];
 position2=DeleteDuplicates[Position[Normal[tempt2],_?(#<0&)][[;;,2;;3]]];
 position=DeleteDuplicates[Join[position,position2]];
 Table[Set[raw[[position[[i,1]],position[[i,2]]]],0],{i,Length[position]}];
 raw];
*)
training=Table[Block[{tempt=Import[trainingfile[[i]]],forecast,obserH,obserL},
  forecast=Normal[tempt["forecast"]];
  obserH=Normal[tempt["observation_H"]];
  obserL=Normal[tempt["observation_L"]];
  Table[Set[obserH[[;;,var]],Map[#*maskO&,obserH[[;;,var]]]],{var,{-2,-1}}];
  Table[Set[obserL[[;;,var]],Map[#*maskS&,obserL[[;;,var]]]],{var,{-2,-1}}];
  forecast=Append[Table[Map[(#-meanvarforecast[[var,1]])/(meanvarforecast[[var,2]]+10^-7)&,forecast[[;;,var]]],{var,7}],Log[forecast[[;;,-1]]+1.]];
  obserH=Append[Table[Map[(#-meanvarobserH[[var,1]])/(meanvarobserH[[var,2]]+10^-7)&,obserH[[;;,var]]],{var,7}],Log[obserH[[;;,-1]]+1.]];
  obserL=Append[Table[Map[(#-meanvarobserL[[var,1]])/(meanvarobserL[[var,2]]+10^-7)&,obserL[[;;,var]]],{var,7}],Log[obserL[[;;,-1]]+1.]];
  Table[Set[obserH[[var]],Map[#*maskO&,obserH[[var]]]],{var,{-2,-1}}];
  Table[Set[obserL[[var]],Map[#*maskS&,obserL[[var]]]],{var,{-2,-1}}];
  Table[Set[forecast[[var]],Map[#*maskS&,forecast[[var]]]],{var,{-2,-1}}];
  Print[i];
  Print[{MinMax[forecast],MinMax[obserH],MinMax[obserL]}];
  {NumericArray[forecast,"Real32"],NumericArray[obserH,"Real32"],NumericArray[obserL,"Real32"]}],{i,Length[trainingfile]}];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/training.mx",training];

validation=Table[Block[{tempt=Import[validationfile[[i]]],forecast,obserH,obserL},
  forecast=Normal[tempt["forecast"]];
  obserH=Normal[tempt["observation_H"]];
  obserL=Normal[tempt["observation_L"]];
  Table[Set[obserH[[;;,var]],Map[#*maskO&,obserH[[;;,var]]]],{var,{-2,-1}}];
  Table[Set[obserL[[;;,var]],Map[#*maskS&,obserL[[;;,var]]]],{var,{-2,-1}}];
  forecast=Append[Table[Map[(#-meanvarforecast[[var,1]])/(meanvarforecast[[var,2]]+10^-7)&,forecast[[;;,var]]],{var,7}],Log[forecast[[;;,-1]]+1.]];
  obserH=Append[Table[Map[(#-meanvarobserH[[var,1]])/(meanvarobserH[[var,2]]+10^-7)&,obserH[[;;,var]]],{var,7}],Log[obserH[[;;,-1]]+1.]];
