var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem={Log[Import["Elevation.mx"][[1]]+1.]};(*{368, 493}, 4km*4km*)
{maskO,maskS}=Block[{a,b},
  {a,b}=Values[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/mask.mx"]];
  {a,b}={Join[Table[1,{6},{Length[a]},{Dimensions[a][[2]]}],Table[a,2]],Join[Table[1,{6},{Length[b]},{Dimensions[b][[2]]}],Table[b,2]]};
  {Transpose[Table[a,{3}]],Transpose[Table[b,{3}]]}];
training=Normal[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/training.mx"]];
validation=Normal[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/validation.mx"]];

vobser=Block[{p,t,reanalysis,norm},
 SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/"];
 p=Normal[Import["P_M.mx"]["data"][[DateDifference[{1981,12,31},{1991,1,1}][[1]];;DateDifference[{1981,12,31},{1996,12,31}][[1]]]]];
 t=Normal[Import["T_M.mx"]["data"][[DateDifference[{1981,12,31},{1991,1,1}][[1]];;DateDifference[{1981,12,31},{1996,12,31}][[1]]]]];
 SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis"];
 reanalysis=Flatten[Map[Block[{tempt=Normal[Import[DateString[#,{"Year","_","Month",".mx"}]]["data"]][[1;;-2]]},
	Mean[Table[tempt[[i;;-1;;24]],{i,1,24}]]]&,DateRange[{1991,1,1},{1996,12,1},"Month"]],1];
 norm=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Normalization.mx"]["meanvarobser"];
 reanalysis=Table[(reanalysis[[date,var]]-norm[[var,1]])/(norm[[var,2]]+10^-7),{date,Length[reanalysis]},{var,Dimensions[reanalysis][[2]]}];
 t=Table[(t[[i]]-norm[[-1,1]])/(norm[[-1,2]]+10^-7)*maskO[[-2,1]],{i,Length[t]}];
 p=Log[Map[#*maskO[[-1,1]]&,p]+1.];
 Table[Join[reanalysis[[i]],{t[[i]],p[[i]]}],{i,Length[p]}]];

(*preparation*)
channel=8;
day=3;
dimS={channel,day,16,22};
dimO={channel,day,31,43};
contract[channel_,crop_:{{1,1},{1,1}}]:=NetGraph[{
				   "conv"->{ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                                            ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp},
                                   "pooling"->PoolingLayer[{1,2,2},{1,2,2},{0,1,1}],
                                   "cropping"->PartLayer[{;;,crop[[1,1]];;-crop[[1,-1]],crop[[2,1]];;-crop[[2,-1]]}]},
                         {NetPort["Input"]->"conv"->"pooling"->NetPort["Pooling"],"conv"->"cropping"->NetPort["Shortcut"]}];
ResizeLayer3D[n_, {dimInx_, dimIny_, dimInz_}] :=Block[{sc = 2},
  NetChain[{
    FlattenLayer[1, "Input" -> {n sc, dimInx, dimIny, dimInz}],    
    ResizeLayer[{Scaled[sc], Scaled[sc]}],
    ReshapeLayer[{n sc, dimInx, sc dimIny, sc dimInz}],
    TransposeLayer[2 <-> 3],
    FlattenLayer[1],
    ResizeLayer[{Scaled[sc], Scaled[1]}],
    ReshapeLayer[{n sc, sc dimIny, sc dimInx, sc dimInz}],
    TransposeLayer[2 <-> 3],
    ConvolutionLayer[n, 1]}]]
ClearAll[expand];
expand[channel_,{dimInx_, dimIny_, dimInz_},pad_:{1,1,1}]:=NetGraph[
		{"deconv"->{ResizeLayer3D[channel,{dimInx,dimIny,dimInz}],BatchNormalizationLayer[],Ramp,PartLayer[{;;,pad[[1]];;-2,pad[[2]];;-2,pad[[3]];;-2}]},
         "join"->CatenateLayer[],
         "conv"->{ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                  ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp}},
        {NetPort["Input"]->"deconv"->"join",NetPort["Shortcut"]->"join"->"conv"}]

RS2O=Block[{dim=dimS},
NetInitialize[NetGraph[<|
  "contract_1"->contract[16],
  "contract_2"->contract[32],
  "contract_3"->contract[64],
  "contract_4"->contract[128],
  "ubase"->{ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,DropoutLayer[0.5]},
  "expand_4"->expand[64,{3,2,3},{3,1,2}],
  "expand_3"->expand[32,{3,3,4},{3,1,1}],
  "expand_2"->expand[16,{3,5,7},{3,1,2}],
  "expand_1"->expand[8,{3,9,12},{3,2,2}]|>,
  {NetPort["Input"]->"contract_1",
   NetPort["contract_1","Pooling"]->"contract_2",
   NetPort["contract_2","Pooling"]->"contract_3",
   NetPort["contract_3","Pooling"]->"contract_4",
   NetPort["contract_4","Pooling"]->"ubase",
   "ubase"->NetPort["expand_4","Input"],
   NetPort["contract_4","Shortcut"]->NetPort["expand_4","Shortcut"],
   NetPort["expand_4","Output"]->NetPort["expand_3","Input"],
   NetPort["contract_3","Shortcut"]->NetPort["expand_3","Shortcut"],
   NetPort["expand_3","Output"]->NetPort["expand_2","Input"],
   NetPort["contract_2","Shortcut"]->NetPort["expand_2","Shortcut"],
    NetPort["expand_2","Output"]->NetPort["expand_1","Input"],
   NetPort["contract_1","Shortcut"]->NetPort["expand_1","Shortcut"]},
   "Input"->dimS]]];

RO2S=Block[{dim=dimO},
NetInitialize[NetGraph[<|
  "contract_1"->contract[16],
  "contract_2"->contract[32],
  "contract_3"->contract[64],
  "contract_4"->contract[128],
  "ubase"->{ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,DropoutLayer[0.5]},
  "expand_4"->expand[64,{3,3,4},{3,1,1}],
  "expand_3"->expand[32,{3,5,7},{3,1,2}],
  "expand_2"->expand[16,{3,9,12},{3,2,2}],
  "expand_1"->expand[8,{3,16,22},{3,1,1}]|>,
  {NetPort["Input"]->"contract_1",
   NetPort["contract_1","Pooling"]->"contract_2",
   NetPort["contract_2","Pooling"]->"contract_3",
   NetPort["contract_3","Pooling"]->"contract_4",
   NetPort["contract_4","Pooling"]->"ubase",
   "ubase"->NetPort["expand_4","Input"],
   NetPort["contract_4","Shortcut"]->NetPort["expand_4","Shortcut"],
   NetPort["expand_4","Output"]->NetPort["expand_3","Input"],
   NetPort["contract_3","Shortcut"]->NetPort["expand_3","Shortcut"],
   NetPort["expand_3","Output"]->NetPort["expand_2","Input"],
   NetPort["contract_2","Shortcut"]->NetPort["expand_2","Shortcut"],
   NetPort["expand_2","Output"]->NetPort["expand_1","Input"],
   NetPort["contract_1","Shortcut"]->NetPort["expand_1","Shortcut"]},
   "Input"->dimO]]];

Dele={1,368, 493};
ele=NetChain[{ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		  ConvolutionLayer[2,{2,4}],BatchNormalizationLayer[],
		  ReplicateLayer[3],TransposeLayer[]},"Input"->Dele];

eleO=NetChain[{ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
                  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
                  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
                  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,
                  ConvolutionLayer[2,{4,8}],BatchNormalizationLayer[],
                  ReplicateLayer[3],TransposeLayer[]},"Input"->Dele]



(*pSR*)
choice1=Hold[Block[{pSR,globe,Report},
Print["p_simulation_regularization"];
pSR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_p_simulation_regularization.mx"];
globe=Block[{net=pSR,size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[-1]],{i,Length[data]}];
  corr=Table[If[maskS[[-1,1,j,k]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2]];

Report[net_]:=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[-1]],{i,Length[data]}];
  corr=Table[If[maskS[[-1,1,j,k]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_p_simulation_regularization_keep.mx",net];
       Set[globe,result]]]];

NetTrain[pSR,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[maskS,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-5},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];
]]

	  
(*tSR*)
choice2=Hold[Block[{tSR,globe,Report},
Print["t_simulation_regularization"];
tSR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_t_simulation_regularization.mx"];
globe=Block[{net=tSR,size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[7]],{i,Length[data]}];
  corr=Table[If[maskS[[-1,1,j,k]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2]];

Report[net_]:=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[7]],{i,Length[data]}];
  corr=Table[If[maskS[[-1,1,j,k]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_t_simulation_regularization_keep.mx",net];
       Set[globe,result]]]];

NetTrain[tSR,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[maskS,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-5},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];
]]


(*futureSR*)
choice3=Hold[Block[{futureSR,globe,Report},
Print["future_simulation_regularization"];
futureSR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_future_simulation_regularization.mx"];

globe=Block[{net=futureSR,size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,3]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2]];

Report[net_]:=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,3]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_future_simulation_regularization_keep.mx",net];
       Set[globe,result]]]];

NetTrain[futureSR,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[maskS,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-5},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];
]]

(*yesterdaySR*)
choice4=Hold[Block[{yesterdaySR,globe,Report},
Print["yesterday_simulation_regularization"];
yesterdaySR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_yesterday_simulation_regularization.mx"];

globe=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result,net=yesterdaySR},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,1]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2]];
Report[net_]:=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=RandomSample[Range[Length[validation]]][[1;;size]];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->maskS|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,1]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_yesterday_simulation_regularization_keep.mx",net];
       Set[globe,result]]]];

NetTrain[yesterdaySR,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[maskS,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-5},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];
]]


(*pOR*)
choice5=Hold[Block[{pOR,globe,Report},
Print["p_observation_regularization"];
pOR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_p_observation_regularization.mx"];

globe=Block[{data,model,simu,obser,corr,result,net=pOR},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[8]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2]];

Report[net_]:=Block[{data,model,simu,obser,corr,result},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[8]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_p_observation_regularization_keep.mx",net];
       Set[globe,result]]]];

NetTrain[pOR,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],2]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[maskO,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-5},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];
]]

(*tOR*)
choice6=Hold[Block[{tOR,globe,Report},
Print["t_observation_regularization"];
tOR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_t_observation_regularization.mx"];

globe=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result,net=tOR},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[7]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2]];
Report[net_]:=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[7]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_t_observation_regularization_keep.mx",net];
       Set[globe,result]]]];

NetTrain[tOR,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],2]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[maskO,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-5},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];
]]

(*futureOR*)
choice7=Hold[Block[{futureOR,globe,Report},
Print["future_observation_regularization"];
futureOR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_future_observation_regularization.mx"];

globe=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result,net=futureOR},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,3]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2]];
Report[net_]:=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,3]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_future_observation_regularization_keep.mx",net];
       Set[globe,result]]]];

NetTrain[futureOR,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],2]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[maskO,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-5},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];
]]


(*yesterdayOR*)
choice8=Hold[Block[{yesterdayOR,globe,Report},
Print["yesterday_observation_regularization"];
yesterdayOR=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/trained_yesterday_observation_regularization.mx"];

globe=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result,net=yesterdayOR},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,1]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2]];
Report[net_]:=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  data=Table[<|"Input"->Transpose[vobser[[i;;i+2]]],"Elevation"->dem,"Mask"->maskO|>,{i,Length[vobser]-2}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[data[[i]]["Input"][[;;,1]],{i,Length[data]}];
  corr=Table[If[Variance[obser[[;;,i,j,k]]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_yesterday_observation_regularization_keep.mx",net];
       Set[globe,result]]]];

NetTrain[yesterdayOR,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],2]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[maskO,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-5},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];
]]
