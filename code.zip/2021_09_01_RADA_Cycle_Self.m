var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem=NumericArray[{Log[Import["Elevation.mx"][[1]]+1.]},"Real32"];(*{368, 493}, 4km*4km*)
training=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/training.mx"][[;;,{1,3}]];
validation=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/validation.mx"][[;;,{1,3}]];
mask=Block[{tempt=Variance[Normal[training[[1,1,-1]]]]},
  NumericArray[Table[If[And[c>6,tempt[[i,j]]==0.],0,1],{c,8},{d,3},{i,Length[tempt]},{j,Dimensions[tempt][[2]]}],"Real32"]];
Import["/g/g92/pan11/CycleGAN_HD/RADA_Model.m"];

S2Of = NetInsertSharedArrays[S2O, "S2O/"];
S2Ob = NetInsertSharedArrays[S2O, "S2O/"];
S2Os = NetInsertSharedArrays[S2O, "S2O/"];

O2Sf = NetInsertSharedArrays[O2S, "O2S/"];
O2Sb = NetInsertSharedArrays[O2S, "O2S/"];
O2Ss = NetInsertSharedArrays[O2S, "O2S/"];

RADA=NetInitialize[NetGraph[<|
		   "S2Of"->S2Of,
		   "O2Sf"->O2Sf,
		   "DS2O"->NetMapOperator[DS2O],
		   "DO2S"->NetMapOperator[DO2S],
		   
		   "Cat_S2O"->CatenateLayer[],
           "Reshape_S2O" -> ReshapeLayer[Prepend[dim,2]],
           "Flat_S2O" -> ReshapeLayer[{2}],
           "Fake_S2O"->PartLayer[1],
           "Real_S2O"->PartLayer[2],
           "Scale_S2O" -> ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0],
           
           "Cat_O2S"->CatenateLayer[],
           "Reshape_O2S" -> ReshapeLayer[Prepend[dim,2]],
           "Flat_O2S" -> ReshapeLayer[{2}],
           "Fake_O2S"->PartLayer[1],
           "Real_O2S"->PartLayer[2],
           "Scale_O2S" -> ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0],
		   
		   "O2Sb"->O2Sb,
		   "S2Ob"->S2Ob,
		   "MSE_S2O2S"->MeanAbsoluteLossLayer[],
		   "MSE_O2S2O"->MeanAbsoluteLossLayer[],
		   
		   "S2Os"->S2Os,
		   "O2Ss"->O2Ss,
		   "MSE_S2Os"->MeanAbsoluteLossLayer[],
		   "MSE_O2Ss"->MeanAbsoluteLossLayer[]
		   |>,
 {NetPort["S"]->NetPort["S2Of","GCM"],
  NetPort["Elevation"]->NetPort["S2Of","DEM"],
  NetPort["Mask"]->NetPort["S2Of","Mask"],
  "S2Of"->"Cat_S2O",
  NetPort["O"]->"Cat_S2O",
  "Cat_S2O"->"Reshape_S2O"->"DS2O"->"Flat_S2O"->"Scale_S2O",
  "Scale_S2O"->"Fake_S2O"->NetPort["Fake_S2O"],
  "Scale_S2O"->"Real_S2O"->NetPort["Real_S2O"],
  
  NetPort["O"]->NetPort["O2Sf","Obser"],
  NetPort["Mask"]->NetPort["O2Sf","Mask"],
  NetPort["Elevation"]->NetPort["O2Sf","DEM"],
  "O2Sf"->"Cat_O2S",
  NetPort["S"]->"Cat_O2S",
  "Cat_O2S"->"Reshape_O2S"->"DO2S"->"Flat_O2S"->"Scale_O2S",
  "Scale_O2S"->"Fake_O2S"->NetPort["Fake_O2S"],
  "Scale_O2S"->"Real_O2S"->NetPort["Real_O2S"],
  
  "S2Of"->NetPort["O2Sb","Obser"],
  NetPort["Mask"]->NetPort["O2Sb","Mask"],
  NetPort["Elevation"]->NetPort["O2Sb","DEM"],
  "O2Sb"->"MSE_S2O2S",
  NetPort["S"]->"MSE_S2O2S"->NetPort["Cycle_S2O"],
  
  "O2Sf"->NetPort["S2Ob","GCM"],
  NetPort["Mask"]->NetPort["S2Ob","Mask"],
  NetPort["Elevation"]->NetPort["S2Ob","DEM"],
  "S2Ob"->"MSE_O2S2O",
  NetPort["O"]->"MSE_O2S2O"->NetPort["Cycle_O2S"],
  
  NetPort["O"]->NetPort["S2Os","GCM"],
  NetPort["Elevation"]->NetPort["S2Os","DEM"],
  NetPort["Mask"]->NetPort["S2Os","Mask"],
  "S2Os"->"MSE_S2Os",
  NetPort["O"]->"MSE_S2Os"->NetPort["S2O_Self"],
  
  NetPort["S"]->NetPort["O2Ss","Obser"],
  NetPort["Elevation"]->NetPort["O2Ss","DEM"],
  NetPort["Mask"]->NetPort["O2Ss","Mask"],
  "O2Ss"->"MSE_O2Ss",
  NetPort["S"]->"MSE_O2Ss"->NetPort["O2S_Self"]
  }]]




globe=Infinity;
index=StringSplit[CreateUUID[],"-"][[1]];
Report[net_]:=Block[{n1=10,n2=10,choice1,choice2,data,model,correction,obser,energy,energyraw},
  choice1=RandomSample[Range[Length[validation]],n1];
  choice2=Table[RandomSample[Range[Dimensions[validation[[q,2]]][[2]]-2]][[1;;n2]],{q,choice1}];
  data=Flatten[Table[<|"S"->validation[[choice1[[i]],1]][[;;,choice2[[i,j]];;choice2[[i,j]]+2]],
               "O"->validation[[choice1[[i]],2]][[;;,choice2[[i,j]];;choice2[[i,j]]+2]],
               "Elevation"->dem,
               "Mask"->mask|>,{i,n1},{j,n2}],1];
  model=NetTake[net,"S2Of"];
  correction=Map[model[#,TargetDevice->"GPU"]&,data[[;;,{1,3,4}]]];
  obser=data[[;;,2]];
  raw=data[[;;,1]];
  {correction,obser,raw}=Map[Normal,{correction,obser,raw}];
  Print[MinMax[correction]];
  correction=Map[Flatten,correction];
  obser=Map[Flatten,obser];
  raw=Map[Flatten,raw];
  energy=2*Total[Flatten[Table[EuclideanDistance[correction[[i]],obser[[j]]],{i,Length[correction]},{j,Length[obser]}]]]-
        Total[Flatten[Table[EuclideanDistance[correction[[i]],correction[[j]]],{i,Length[correction]},{j,Length[correction]}]]]-
        Total[Flatten[Table[EuclideanDistance[obser[[i]],obser[[j]]],{i,Length[obser]},{j,Length[obser]}]]];
  energyraw=2*Total[Flatten[Table[EuclideanDistance[raw[[i]],obser[[j]]],{i,Length[correction]},{j,Length[obser]}]]]-
        Total[Flatten[Table[EuclideanDistance[raw[[i]],raw[[j]]],{i,Length[correction]},{j,Length[correction]}]]]-
        Total[Flatten[Table[EuclideanDistance[obser[[i]],obser[[j]]],{i,Length[obser]},{j,Length[obser]}]]];
  Print["globe\t energy value after\t energy value before"];
  Print[index];
  Print[{globe,energy,energyraw}];
  If[energy<globe,
     Block[{},
       Print["Update"];
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_RADA_Cycle_Self_"<>index<>".mx",net];
       Set[globe,energy]]]];

NetTrain[RADA,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"S"->Table[training[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "O"->Table[training[[choice1[[i]],2]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[mask,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  LossFunction ->{"Fake_S2O"->Scaled[3],"Real_S2O"->Scaled[3],"Cycle_S2O"->Scaled[-1],"O2S_Self"->Scaled[-1],
                  "Fake_O2S"->Scaled[3],"Real_O2S"->Scaled[3],"Cycle_O2S"->Scaled[-1],"S2O_Self"->Scaled[-1]},
  TrainingUpdateSchedule -> {"DS2O"|"DO2S",
                             "O2Sf"|"S2Of",
                             "O2Ss"|"S2Os",
                             "O2Sb"|"S2Ob"},
  LearningRateMultipliers -> {"DS2O"->3,"DO2S"->3,
                              "O2Sf"->-1,"S2Of"->-1,
                              "O2Sb"->-1,"S2Ob"->-1,
                              "O2Ss"->-1,"S2Os"->-1,
                              "Scale_S2O"->0,"Scale_O2S"->0},
  BatchSize -> 64,
  TargetDevice->{"GPU",1},
  WorkingPrecision->"Real32",
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-4,"L2Regularization"->10^-2,
        "WeightClipping" -> {"DS2O"-> 0.5,"DO2S"->0.5,_->3}},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[100, "Batches"]},"Print"}];


(*
NetTrain[RADA,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"S"->Table[training[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "O"->Table[training[[choice1[[i]],2]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[mask,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  LossFunction ->{"Fake_S2O"->Scaled[0],"Real_S2O"->Scaled[0],"Cycle_S2O"->Scaled[-1],"O2S_Self"->Scaled[-1],
                  "Fake_O2S"->Scaled[0],"Real_O2S"->Scaled[0],"Cycle_O2S"->Scaled[-1],"S2O_Self"->Scaled[-1]},
  TrainingUpdateSchedule -> {"DS2O"|"DO2S",
                             "O2Sf"|"S2Of",
                             "O2Ss"|"S2Os",
                             "O2Sb"|"S2Ob"},
  LearningRateMultipliers -> {"DS2O"->3,"DO2S"->3,
                              "O2Sf"->-1,"S2Of"->-1,
                              "O2Sb"->-1,"S2Ob"->-1,
                              "O2Ss"->-1,"S2Os"->-1,
                              "Scale_S2O"->0,"Scale_O2S"->0},
  BatchSize -> 64,
  TargetDevice->{"GPU",1},
  WorkingPrecision->"Real32",
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-4,
        "WeightClipping" -> {"DS2O"-> 0.5,"DO2S"->0.5,_->3}},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[10, "Batches"]},"Print"}];
*)
