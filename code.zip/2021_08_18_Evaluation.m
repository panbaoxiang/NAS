test=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/test.mx"];
test=Select[test,#[[3,2]]==7&];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem={Log[Import["Elevation.mx"][[1]]+1.]};(*{368, 493}, 4km*4km*)
{maskO,maskS}=Block[{a,b},
  {a,b}=Values[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/mask.mx"]];
  {a,b}={Join[Table[1,{6},{Length[a]},{Dimensions[a][[2]]}],Table[a,2]],Join[Table[1,{6},{Length[b]},{Dimensions[b][[2]]}],Table[b,2]]};
  {Transpose[Table[a,{3}]],Transpose[Table[b,{3}]]}];

RADA=Block[{model=Import["/usr/workspace/pan11/CycleGAN_HD/Result/trained_RADA_6dd40f3f.mx"]},
 NetTake[model,"S2Of"]];

result=Table[Block[{tempt=test[[i,1]],obser=Transpose[Normal[test[[i,2]][[;;,2;;]]]]},
	Print[i];
	simu=Normal[Table[RADA[<|"MaskO"->maskO,"S"->tempt[[;;,i;;i+2]],"Elevation"->dem|>,TargetDevice->"GPU"][[;;,2]],{i,1,Dimensions[tempt][[2]]-2}]];
	{NumericArray[simu,"Real32"],NumericArray[obser,"Real32"]}],{i,Length[test]}];

lead={75,230};
var=1;
forecast=Table[{Mean[Normal[result[[i,1]][[lead[[1]];;lead[[2]],var]]]],Mean[Normal[result[[i,2]][[lead[[1]];;lead[[2]],var]]]]},{i,Length[result]}];
corr=Table[If[And[Variance[forecast[[;;,1,i,j]]]>0,Variance[forecast[[;;,2,i,j]]]>0],
	Correlation[forecast[[;;,1,i,j]],forecast[[;;,2,i,j]]],Null],{i,Dimensions[forecast][[3]]},{j,Dimensions[forecast][[4]]}];
Mean[Select[Flatten[corr],NumberQ]] 

