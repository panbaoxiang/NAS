obser=Normal[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/obser.mx"]["data_L"]];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
Table[ToExpression["pR"<>ToString[i]<>"=Normal[Import[\"P_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];

masks=Table[Block[{mp=Mean[Normal[ToExpression["pR"<>ToString[ii]]]],position},
  position=Table[If[mp[[i,j]]>0,1,0],{i,Length[mp]},{j,Dimensions[mp][[2]]}];
  position],{ii,5}];
Table[ToExpression["pR"<>ToString[i]<>"=(Log[Map[#*masks[["<>ToString[i]<>"]]&,pR"<>ToString[i]<>"]+1.])[[1;;Length[obser]]];"],{i,5}];

data=Block[{meanvar,tempt,p},
 meanvar=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Normalization.mx"]["meanvarobser_L"];
 tempt=Table[Map[(#-meanvar[[i,1]])/(meanvar[[i,2]]+10^-6)&,obser[[;;,i]]],{i,7}];
 tempt=Transpose[Join[tempt,{pR1}]];
 Table[<|"Input"->tempt[[i]],
         "Output_R1"->{pR2[[i]]},
         "Output_R2"->{pR3[[i]]},
         "Output_R3"->{pR4[[i]]},
         "Output_R4"->{pR5[[i]]}|>,{i,Length[tempt]}]];

ele=Block[{tempt=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Elevation.mx"]["Elevation"]},
 tempt=(tempt /. x_ /; x<-0.->0);
 {Log[tempt+1.]}];


test=Range[Round[Length[data]*0.85],Length[data]];
testset= Table[<|"Input"->data[[i,"Input"]],
   "Mask1"->{masks[[2]]},
   "Output_R1"->data[[i,"Output_R1"]],
   "Mask2"->{masks[[3]]},
   "Output_R2"->data[[i,"Output_R2"]],
   "Mask3"->{masks[[4]]},
   "Output_R3"->data[[i,"Output_R3"]],
   "Mask4"->{masks[[5]]},
   "Output_R4"->data[[i,"Output_R4"]],
   "Elevation"->ele|>,{i,test}];

net=Import["/usr/workspace/pan11/CycleGAN_HD/Result/P_Downscaling.mx"];

simu=Exp[Map[net[#,TargetDevice->"GPU"]&,testset[[;;,{"Input","Mask1","Mask2","Mask3","Mask4","Elevation"}]]]]-1.;
obser=Exp[testset[[;;,{"Output_R1","Output_R2","Output_R3","Output_R4"}]]]-1.;
  
corr=Table[Block[{s=simu[[;;,"Output_R"<>ToString[i]]],o=testset[[;;,"Output_R"<>ToString[i]]]},
   Table[If[Variance[s[[;;,1,a,b]]]==0,-1,Correlation[s[[;;,1,a,b]],o[[;;,1,a,b]]]],{a,Dimensions[s][[3]]},{b,Dimensions[s][[4]]}]],{i,4}];

summary=Map[Mean[Select[Flatten[#],#>-.4&]]&,corr];
Print[summary];

Export["/usr/workspace/pan11/CycleGAN_HD/Result/P_Downscaling_Result.mx",
  <|"simu"->simu,
    "obser"->obser,
    "date"->DatePlus[{1981,12,31},Round[Length[data]*0.85]]|>];
