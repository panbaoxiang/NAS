channel=8;
day=3;
dim={channel,day,16,22};
dimH={1, 368, 493};

contract[channel_,crop_:{{1,1},{1,1}}]:=NetGraph[{"conv"->{ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                                                           ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp},
                                   "pooling"->PoolingLayer[{1,2,2},{1,2,2},{0,1,1}],
                                   "cropping"->PartLayer[{;;,crop[[1,1]];;-crop[[1,-1]],crop[[2,1]];;-crop[[2,-1]]}]},
                         {NetPort["Input"]->"conv"->"pooling"->NetPort["Pooling"],"conv"->"cropping"->NetPort["Shortcut"]}]

ResizeLayer3D[n_, {dimInx_, dimIny_, dimInz_}] :=
 Block[{sc = 2},
  NetChain[{
    (* Flattens the first two levels so because the next layer only works on 2D arrays *)        
    FlattenLayer[1, "Input" -> {n sc, dimInx, dimIny, dimInz}],    
    (* Doubles the size of the last two dimensions *)        
    ResizeLayer[{Scaled[sc], Scaled[sc]}],
    (* Reshapes the array back to its original order but with the  last two dimensions scaled up from previous layer *)        
    ReshapeLayer[{n sc, dimInx, sc dimIny, sc dimInz}],
    (* Transposes 2nd and 3rd dimensions so that previously unscaled dimension can be actioned *)
    TransposeLayer[2 <-> 3],
    (* Again flatten array a level so that the next later can actually action it *)
    FlattenLayer[1],
    (* Scale only the dimension that hasn't been actioned yet *)        
    ResizeLayer[{Scaled[sc], Scaled[1]}],
    (* Reshape back to original structure but the array now has been scaled up *)
    ReshapeLayer[{n sc, sc dimIny, sc dimInx, sc dimInz}],
    (* importantly, transpose the dimensions back to their original order since it was changed above*)
    TransposeLayer[2 <-> 3],
    (* Now a convolution can be applied to the upsampled up data *)
    ConvolutionLayer[n, 1]}
   ]]

ClearAll[expand];
expand[channel_,{dimInx_, dimIny_, dimInz_},pad_:{1,1,1},RAMP_:1]:=NetGraph[
		{"deconv"->{ResizeLayer3D[channel,{dimInx,dimIny,dimInz}],BatchNormalizationLayer[],Ramp,PartLayer[{;;,pad[[1]];;-2,pad[[2]];;-2,pad[[3]];;-2}]},
         "join"->CatenateLayer[],
         "conv"->If[RAMP==1,
                 {ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                  ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp},
                 {ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                  ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[]}]},
        {NetPort["Input"]->"deconv"->"join",NetPort["Shortcut"]->"join"->"conv"}]


ele=NetChain[{ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		  ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		  ConvolutionLayer[2,{2,4}],BatchNormalizationLayer[],
		  ReplicateLayer[3],TransposeLayer[]},
 "Input"->dimH];

(*
Unet=Block[{dim=dim},
NetInitialize[NetGraph[<|
  "contract_1"->contract[16],
  "contract_2"->contract[32],
  "contract_3"->contract[64],
  "contract_4"->contract[128],
  "ubase"->{ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,DropoutLayer[0.5]},
  "expand_4"->expand[64,{3,2,3},{3,1,2}],
  "expand_3"->expand[32,{3,3,4},{3,1,1}],
  "expand_2"->expand[16,{3,5,7},{3,1,2}],
  "expand_1"->expand[8,{3,9,12},{3,2,2},0]|>,
  {NetPort["Input"]->"contract_1",
   NetPort["contract_1","Pooling"]->"contract_2",
   NetPort["contract_2","Pooling"]->"contract_3",
   NetPort["contract_3","Pooling"]->"contract_4",
   NetPort["contract_4","Pooling"]->"ubase",
   "ubase"->NetPort["expand_4","Input"],
   NetPort["contract_4","Shortcut"]->NetPort["expand_4","Shortcut"],
   NetPort["expand_4","Output"]->NetPort["expand_3","Input"],
   NetPort["contract_3","Shortcut"]->NetPort["expand_3","Shortcut"],
   NetPort["expand_3","Output"]->NetPort["expand_2","Input"],
   NetPort["contract_2","Shortcut"]->NetPort["expand_2","Shortcut"],
    NetPort["expand_2","Output"]->NetPort["expand_1","Input"],
   NetPort["contract_1","Shortcut"]->NetPort["expand_1","Shortcut"]},
   "Input"->{10,3,16,22}]]];
*)

Unet=NetChain[{ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1}],BatchNormalizationLayer[],Ramp,
			   ConvolutionLayer[32,{3,3,3},"PaddingSize"->{1,1,1}],BatchNormalizationLayer[],Ramp,
			   ConvolutionLayer[64,{3,3,3},"PaddingSize"->{1,1,1}],BatchNormalizationLayer[],Ramp,
			   ConvolutionLayer[8,{3,3,3},"PaddingSize"->{1,1,1}],BatchNormalizationLayer[]},
 "Input"->{10,3,16,22}];


post=NetGraph[<|"Part1"->PartLayer[1;;7],
			    "Part2"->PartLayer[8;;8],
			    "Ramp"->Ramp,
			    "Combine"->CatenateLayer[]|>,
 {NetPort["Input"]->"Part1"->"Combine",
  NetPort["Input"]->"Part2"->"Ramp"->"Combine"}];

S2O=NetGraph[<|"u"->Unet,
               "ele"->ele,
               "blend"->CatenateLayer[],
               "plus"->ThreadingLayer[Plus],
               "post"->post,
               "thread"->ThreadingLayer[Times]|>,
 {NetPort["GCM"]->"blend",
  NetPort["DEM"]->"ele"->"blend"->"u"->"plus",
  NetPort["GCM"]->"plus"->"post"->"thread",
  NetPort["Mask"]->"thread"->NetPort["Obser"]},
 "GCM"->dim,
 "DEM"->dimH,
 "Mask"->dim];

O2S=NetGraph[<|"u"->Unet,
               "ele"->ele,
               "blend"->CatenateLayer[],
               "plus"->ThreadingLayer[Plus],
               "post"->post,
               "thread"->ThreadingLayer[Times]|>,
 {NetPort["Obser"]->"blend",
  NetPort["DEM"]->"ele"->"blend"->"u"->"plus",
  NetPort["Obser"]->"plus"->"post"->"thread",
  NetPort["Mask"]->"thread"->NetPort["Obser"]},
 "Obser"->dim,
 "DEM"->dimH,
 "Mask"->dim];

DO2S=NetChain[{ConvolutionLayer[16,{3,3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   FlattenLayer[1],
			   ConvolutionLayer[16,{3,3},"Stride"->2],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   FlattenLayer[],
			   1,
			   ElementwiseLayer["HardSigmoid"]
			   },
	"Input"->dim];
DS2O=NetChain[{ConvolutionLayer[16,{3,3,3}],
                           BatchNormalizationLayer[],
                           Ramp,
                           FlattenLayer[1],
                           ConvolutionLayer[16,{3,3},"Stride"->2],
                           BatchNormalizationLayer[],
                           Ramp,
                           ConvolutionLayer[16,{3,3}],
                           BatchNormalizationLayer[],
                           Ramp,
                           ConvolutionLayer[16,{3,3}],
                           BatchNormalizationLayer[],
                           FlattenLayer[],
                           1,
                           ElementwiseLayer["HardSigmoid"]
                           },
        "Input"->dim];

S2Of = NetInsertSharedArrays[S2O, "S2O/"];
S2Ob = NetInsertSharedArrays[S2O, "S2O/"];

O2Sf = NetInsertSharedArrays[O2S, "O2S/"];
O2Sb = NetInsertSharedArrays[O2S, "O2S/"];

RADA=NetInitialize[NetGraph[<|
		   "S2Of"->S2Of,
		   "O2Sf"->O2Sf,
		   "DS2O"->NetMapOperator[DS2O],
		   "DO2S"->NetMapOperator[DO2S],
		   
		   "Cat_S2O"->CatenateLayer[],
           "Reshape_S2O" -> ReshapeLayer[Prepend[dim,2]],
           "Flat_S2O" -> ReshapeLayer[{2}],
           "Fake_S2O"->PartLayer[1],
           "Real_S2O"->PartLayer[2],
           "Scale_S2O" -> ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0],
           
           "Cat_O2S"->CatenateLayer[],
           "Reshape_O2S" -> ReshapeLayer[Prepend[dim,2]],
           "Flat_O2S" -> ReshapeLayer[{2}],
           "Fake_O2S"->PartLayer[1],
           "Real_O2S"->PartLayer[2],
           "Scale_O2S" -> ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0],
		   
		   "O2Sb"->O2Sb,
		   "S2Ob"->S2Ob,
		   "MSE_S2O2S"->MeanAbsoluteLossLayer[],
		   "MSE_O2S2O"->MeanAbsoluteLossLayer[]
		   |>,
 {NetPort["S"]->NetPort["S2Of","GCM"],
  NetPort["Elevation"]->NetPort["S2Of","DEM"],
  NetPort["Mask"]->NetPort["S2Of","Mask"],
  "S2Of"->"Cat_S2O",
  NetPort["O"]->"Cat_S2O",
  "Cat_S2O"->"Reshape_S2O"->"DS2O"->"Flat_S2O"->"Scale_S2O",
  "Scale_S2O"->"Fake_S2O"->NetPort["Fake_S2O"],
  "Scale_S2O"->"Real_S2O"->NetPort["Real_S2O"],
  
  NetPort["O"]->NetPort["O2Sf","Obser"],
  NetPort["Mask"]->NetPort["O2Sf","Mask"],
  NetPort["Elevation"]->NetPort["O2Sf","DEM"],
  "O2Sf"->"Cat_O2S",
  NetPort["S"]->"Cat_O2S",
  "Cat_O2S"->"Reshape_O2S"->"DO2S"->"Flat_O2S"->"Scale_O2S",
  "Scale_O2S"->"Fake_O2S"->NetPort["Fake_O2S"],
  "Scale_O2S"->"Real_O2S"->NetPort["Real_O2S"],
  
  "S2Of"->NetPort["O2Sb","Obser"],
  NetPort["Mask"]->NetPort["O2Sb","Mask"],
  NetPort["Elevation"]->NetPort["O2Sb","DEM"],
  "O2Sb"->"MSE_S2O2S",
  NetPort["S"]->"MSE_S2O2S"->NetPort["Cycle_S2O"],
  
  "O2Sf"->NetPort["S2Ob","GCM"],
  NetPort["Mask"]->NetPort["S2Ob","Mask"],
  NetPort["Elevation"]->NetPort["S2Ob","DEM"],
  "S2Ob"->"MSE_O2S2O",
  NetPort["O"]->"MSE_O2S2O"->NetPort["Cycle_O2S"]
  }]]
