Import["/g/g92/pan11/CycleGAN_HD/RADA_Regularization.m"];
option=RandomSample[{<|"net"->pR,"set"->1,"channel"->"8","name"->"trained_p_simulation_regularization.mx"|>,
        <|"net"->tR,"set"->1,"channel"->"7","name"->"trained_t_simulation_regularization.mx"|>,
        <|"net"->yesterdayR,"set"->1,"channel"->";;,1","name"->"trained_yesterday_simulation_regularization.mx"|>,
        <|"net"->futureR,"set"->1,"channel"->";;,-1","name"->"trained_tomorrow_simulation_regularization.mx"|>}][[1]];
Print[option["name"]];

var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem=Block[{raw=NumericArray[{Log[Import["Support/Elevation.mx"][[1]]+1.]},"Real32"](*{368, 493}, 4km*4km*),net1,net2,net3},
 net1=NetTake[Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/P_Downscaling.mx"],"ele"];
 net2=NetTake[Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/T_Downscaling.mx"],"ele"];
 NumericArray[Transpose[Table[Flatten[Normal[{net1[raw],net2[raw]}],1],{3}]],"Real32"]];
mask=Import["Support/Mask.mx"][[1]];
nmask=NumericArray[Transpose[Table[Join[ConstantArray[1,Prepend[Dimensions[mask],6]],Table[mask,2]],3]],"Real32"];

Print["Loading"];
data=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/data.mx"];
Print["loaded"];
(*seq=RandomSample[Range[Length[data[[1]]]]];Export["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/Regularization_simulation_seq.mx",seq];*)
seq=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization/Regularization_simulation_seq.mx"];
training=data[[1]][[seq[[1;;Round[Length[seq]*.8]]]]];
validation=data[[1]][[seq[[Round[Length[seq]*.8]+1;;]]]];


choice=Hold[Block[{globe,Report,nn=option["net"],set=option["set"],channel=option["channel"],name=option["name"],straining,svalidation},
{nn,globe}=If[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/Result/"<>name],Block[{tempt=Import["/usr/workspace/pan11/CycleGAN_HD/Result/"<>name]},{tempt["net"],tempt["mse"]}],{nn,Infinity}];
straining=RandomSample[Flatten[Table[Table[<|"Input"->Transpose[training[[i,set]][[j;;j+2]]],"Elevation"->dem,"Mask"->nmask|>,{j,1,Length[training[[i,set]]]-2,3}],{i,Length[training]}]]];
svalidation=RandomSample[Flatten[Table[Table[<|"Input"->Transpose[validation[[i,set]][[j;;j+2]]],"Elevation"->dem,"Mask"->nmask|>,{j,1,Length[validation[[i,set]]]-2,3}],{i,Length[validation]}]]];

Report[net_,valloss_]:=Block[{},
  If[valloss<globe,
     Block[{},
       Print["update"];
       Print[{globe,valloss}];
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/"<>name,<|"net"->net,"mse"->valloss|>];
       Set[globe,valloss]]]];
NetTrain[nn,
  straining,
  ValidationSet->svalidation,
  BatchSize -> 256,
  WorkingPrecision->"Real32",
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-3},
  TrainingProgressReporting -> {{Function@Report[#Net,#ValidationLoss], "Interval" -> Quantity[1, "Rounds"]},"Print"}];]];

ReleaseHold[choice];
