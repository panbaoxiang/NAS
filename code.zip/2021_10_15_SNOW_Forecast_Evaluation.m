SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Observation"];
lat=Import["WUS_SWE_P_T_1983.mx"]["lat"];
lon=Import["WUS_SWE_P_T_1983.mx"]["lon"]+360.;
rgrids=Table[{lat[[i]],lon[[j]]},{i,Length[lat]},{j,Length[lon]}];

obser=Table[Block[{data=Import["WUS_SWE_P_T_"<>ToString[year]<>".mx"],p,t,swe},
	p=data["P"];
	t=data["T"];
	swe=data["SWE"];
	{p,t,swe}],{year,Range[1982,2019]}];

dates=Block[{},SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/P"];
 Map[ToExpression[StringSplit[#,{"_",".mx"}][[1;;4]]]&,FileNames["*mx"]]];

name="NCal";
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Snow/"<>name];
grids=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Polyon/"<>name<>"_grid.mx"][[1,-1]];
base=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Polyon/"<>name<>"_grid.mx"][[2,-1]]; 

forecast=Block[{},
 SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/"];
 p=Map[Block[{tempt=Import[DateString[#,{"P/","Year","_","Month","_","Day","_","Hour",".mx"}]][[;;,-1]]},
  (*Print[#];*)
  Map[Table[#[[;;,grids[[i,1]],grids[[i,2]]]],{i,Length[grids]}]&,tempt]]&,dates];
 t=Map[Block[{tempt=Import[DateString[#,{"T/","Year","_","Month","_","Day","_","Hour",".mx"}]][[;;,-1]]},
  (*Print[#];*)
  Map[Table[#[[;;,grids[[i,1]],grids[[i,2]]]],{i,Length[grids]}]&,tempt]]&,dates];
 {p,t}];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Snow/"<>name<>"_data.mx",forecast];

skills=Table[Block[{},
 Print[ii];
 grid=grids[[ii]];
 gridvalue=Map[Map[Normal[#[[;;,grid[[1]],grid[[2]]]]]&,#]&,training];
 vgridvalue=Map[Map[Normal[#[[;;,grid[[1]],grid[[2]]]]]&,#]&,validation];
 p=gridvalue[[;;,1]];
 t=gridvalue[[;;,2]];
 swe=gridvalue[[;;,3]];
 vp=vgridvalue[[;;,1]];
 vt=vgridvalue[[;;,2]];
 vswe=vgridvalue[[;;,3]];
 {tp,tm,kf,km,r,ci,cl}=Import["Point_"<>ToString[ii]<>".mx"][[-1,-1,1]];
results=Block[{f,a,b}, 
 f[swe_,pt_]:=Block[{ice,liquid,p,t},
   {ice,liquid}=swe;{p,t}=pt;
   ice=ice+If[t<tp,ci*p,0]+If[t<tm,Min[kf(tm-t),liquid],-Min[km(t-tm),ice]];
   liquid=Min[r*ice,liquid+If[t>=tp,cl*p,0]-If[t<tm,Min[kf(tm-t),liquid],-Min[km(t-tm),ice]]];
   {ice,liquid}];
 a=Table[{Map[Total,FoldList[f,{0,0},Transpose[{p[[i]],t[[i]]}]]][[2;;]],swe[[i]]},{i,Length[p]}];
 b=Table[{Map[Total,FoldList[f,{0,0},Transpose[{vp[[i]],vt[[i]]}]]][[2;;]],vswe[[i]]},{i,Length[vp]}];
 Join[a,b]];
If[And[Variance[results[[;;,2,181]]]>0,Variance[results[[;;,1,181]]]>0],
Block[{},
aresults=Correlation[results[[;;,1,181]],results[[;;,2,181]]];
ap=Join[p,vp];
at=Join[t,vt];
aswe=Join[swe,vswe];
bresults1=Correlation[Map[Total,ap[[;;,1;;181]]],aswe[[;;,181]]];
bresults2=Correlation[Map[Total,at[[;;,1;;181]]],aswe[[;;,181]]];
bresults3=Block[{model=LinearModelFit[Transpose[{Map[Total,ap[[;;,1;;181]]],Map[Total,at[[;;,1;;181]]],aswe[[;;,181]]}],{x1,x2},{x1,x2}]},
 Correlation[model[[1,2,1]]+model[[1,2,2]]*Map[Total,ap[[;;,1;;181]]]+model[[1,2,3]]*Map[Total,at[[;;,1;;181]]],aswe[[;;,181]]]];
Print[Mean[aswe[[;;,181]]]]; 
Print[{aresults,bresults1,bresults2,bresults3}];
base[[grid[[1]],grid[[2]]]]->{Mean[aswe[[;;,181]]],aresults,bresults1,bresults2,bresults3}],base[[grid[[1]],grid[[2]]]]->{0,-1,-1,-1,-1}]],{ii,Length[grids]}];

Export["/g/g92/pan11/"<>name<>"_result.mx",skills];
