var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem=NumericArray[{Log[Import["Elevation.mx"][[1]]+1.]},"Real32"];(*{368, 493}, 4km*4km*)
training=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/training.mx"][[;;,{1,3}]];
validation=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/validation.mx"][[;;,{1,3}]];
mask=Block[{tempt=Variance[Normal[training[[1,1,-1]]]]},
  NumericArray[Table[If[And[c>6,tempt[[i,j]]==0.],0,1],{c,8},{d,3},{i,Length[tempt]},{j,Dimensions[tempt][[2]]}],"Real32"]];

training=Flatten[Table[Table[{training[[i,1]][[;;,j;;j+2]]->-1,training[[i,2]][[;;,j;;j+2]]->1},{j,Length[training[[i,1,1]]]-2}],{i,Length[training]}]];
validation=Flatten[Table[Table[{validation[[i,1]][[;;,j;;j+2]]->-1,validation[[i,2]][[;;,j;;j+2]]->1},{j,Length[validation[[i,1,1]]]-2}],{i,Length[validation]}]];

DO2S=NetInitialize[NetChain[{ConvolutionLayer[16,{3,3,3}],
                           BatchNormalizationLayer[],
                           Ramp,
                           FlattenLayer[1],
                           ConvolutionLayer[16,{3,3},"Stride"->2],
                           BatchNormalizationLayer[],
                           Ramp,
                           ConvolutionLayer[16,{3,3}],
                           BatchNormalizationLayer[],
                           Ramp,
                           ConvolutionLayer[16,{3,3}],
                           BatchNormalizationLayer[],
                           FlattenLayer[],
                           2,
                           SoftmaxLayer[]
                           },
        "Input"->Dimensions[training[[1,1]]],
        "Output"->NetDecoder[{"Class",{-1,1}}]]]

trained=NetTrain[DO2S,
  training,
  ValidationSet->validation,
  TargetDevice->{"GPU",2},
  BatchSize -> 64,
  WorkingPrecision->"Real32",
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-4,"WeightClipping" -> 0.5}];
