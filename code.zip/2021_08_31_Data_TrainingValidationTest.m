var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/"];
ele=Log[Import["Support/Elevation.mx"][[1]]+1.];(*{368, 493}, 4km*4km*)
meanvarobser=Import["Support/Normalization.mx"]["meanvarobser"];
meanvarforecast=Import["Support/Normalization.mx"]["meanvarforecast"];
trainingfile=Flatten[Table[FileNames["Paired/"<>ToString[year]<>"*mx"],{year,1982,1990}]];
validationfile=Flatten[Table[FileNames["Paired/"<>ToString[year]<>"*mx"],{year,1991,1996}]];
testfile=Flatten[Table[FileNames["Paired/"<>ToString[year]<>"*mx"],{year,1997,2019}]];
files=Flatten[Table[FileNames["Paired/"<>ToString[year]<>"*mx"],{year,1982,2019}]];
mask=Block[{mask=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Mask.mx"][[1]],base},
 base=Table[1,{k,6},{i,Dimenisons[mask][[1]]},{j,Dimensions[mask][[2]]}];
 Join[base,Table[mask,2]]];
dates=Map[ToExpression[StringSplit[#,{"/","_","."}][[2;;5]]]&,files];
data=Table[Block[{tempt=Import[files[[i]]],forecast,obserH,obser},
  forecast=Normal[tempt["forecast"]];
  obser=Normal[tempt["observation"]];
  forecast=Map[#*mask&,forecast];
  obser=Map[#*mask&,obser];
  forecast=Transpose[Append[Table[Map[(#-meanvarforecast[[var,1]])/(meanvarforecast[[var,2]]+10^-7)&,forecast[[;;,var]]],{var,7}],Log[forecast[[;;,-1]]+1.]]];
  obser=Transpose[Append[Table[Map[(#-meanvarobser[[var,1]])/(meanvarobser[[var,2]]+10^-7)&,obser[[;;,var]]],{var,7}],Log[obser[[;;,-1]]+1.]]];
  forecast=Map[#*mask&,forecast];
  obser=Map[#*mask&,obser];
  Print[i];
  Print[dates[[i]]];
  Print[{MinMax[forecast],MinMax[obser]}];
  {NumericArray[forecast,"Real32"],NumericArray[obser,"Real32"]}],{i,Length[files]}];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/data.mx",<|"data"->data,"dates"->dates|>];
