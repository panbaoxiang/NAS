SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis"];
files=Map[DateString[#,{"Year","_","Month",".mx"}]&,DateRange[{1982,1,1},{2020,11,1},{1,"Month"}]];
var=Import[files[[1]]]["var"];
reanalysis=Table[Block[{tempt,d},
 tempt=Import[files[[i]]]["data"];
 tempt=Table[tempt[[i;;-1;;24]],{i,1,24}];
 d=Min[Map[Length,tempt]];
 Print[files[[i]]];
 tempt=NumericArray[Mean[Normal[Map[#[[;;d]]&,tempt]]],"Real32"];
 tempt],{i,Length[files]}];
reanalysis=Flatten[Normal[reanalysis],1];
lreanalysis=Block[{tempt,tempt2,tempt3},
 tempt=Join[reanalysis,reanalysis[[;;,;;,{-1}]],3];
 tempt2=Join[tempt,tempt[[;;,;;,;;,{-1}]],4];
 tempt3=Table[tempt2[[;;,;;,i;;-1;;2,j;;-1;;2]],{i,2},{j,2}];
 Mean[Mean[tempt3]]];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/reanalysis.mx",
 <|"data_H"->NumericArray[reanalysis,"Real32"],
   "data_L"->NumericArray[lreanalysis,"Real32"],
   "date"->"1982.1.1 to 2018.12.31",
   "lat_H"->Import[files[[1]]]["lat"],
   "lon_H"->Import[files[[1]]]["lon"],
   "lat_L"->Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lat"],
   "lon_L"->Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lon"],
   "var"->Import[files[[1]]]["var"]|>];

reanalysisH=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/reanalysis.mx"]["data_H"];
reanalysisH=Normal[reanalysisH];
reanalysisL=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Reanalysis/reanalysis.mx"]["data_L"];
reanalysisL=Normal[reanalysisL];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
pL=Import["P_R1.mx"]["data"];
tL=Import["T_R1.mx"]["data"];
tpL=Transpose[Normal[{tL,pL}]];
reanalysisL=reanalysisL[[;;Length[tpL]]];
obserL=NumericArray[Table[Join[reanalysisL[[i]],tpL[[i]]],{i,Length[tpL]}],"Real32"];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/obser.mx",
 <|"data"->obserL,
   "date"->"1982.1.1 to 2018.12.31",
   "lat"->Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lat"],
   "lon"->Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/1985_05_01_00.mx"]["lon"],
   "var"->Join[var,{"t2m","p"}]|>];


obserL=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/obser.mx"]["data"];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Forecast/"];
files=FileNames["*mx"];
var=Import[files[[1]]]["var"];
Table[If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Paired/"<>files[[i]]]],
 Block[{start,data,l,startdate,observationH,observationL},
 start=ToExpression[StringSplit[files[[i]],{"_","."}][[1;;-2]]];
 data=Block[{tempt=Import[files[[i]]]["data"]},
   If[start[[-1]]==0,tempt,tempt[[(24-start[[-1]])/6+1;;]]]];
 data=Table[data[[i;;-1;;4]],{i,1,4}];
 l=Min[Map[Length,data]];
 data=Mean[Normal[Map[#[[1;;l]]&,data]]];
 Set[data[[;;,7]],data[[;;,7]]-273.15];
 Set[data[[;;,8]],data[[;;,8]]*3600.*24.];
 data=NumericArray[data,"Real32"];
 startdate=DateDifference[{1981,12,31},If[start[[-1]]==0,start[[1;;3]],DatePlus[start[[1;;3]],1]]][[1]];
 observationL=obserL[[startdate;;(startdate+l-1)]];
 Print[files[[i]]];
 (*forecast precipitation in  "kg.m-2.s-1"*)
 Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Paired/"<>files[[i]],
  <|"forecast"->data,
    "observation"->observationL,
    "var"->var,
    "date"->start|>];]],{i,Length[files]}];


SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Paired"];
files=FileNames["*mx"];
files=RandomSample[files,3000];
Off[General::stop];
(*
data=Table[Block[{tempt,forecast,obserH,obseL},
 Print[files[[i]]];
 tempt=Import[files[[i]]];
 forecast=tempt["forecast"];
 obserH=tempt["observation"];
 c1=And[Min[forecast[[;;,1]]]>50000,Max[forecast[[;;,1]]]<150000,
  Min[forecast[[;;,2]]]>=0., Max[forecast[[;;,2]]]<0.5,
  Min[forecast[[;;,3]]]>=0.,Max[forecast[[;;,3]]]<0.5,
  Min[forecast[[;;,4]]]>=0.,Max[forecast[[;;,4]]]<0.5,
  Min[forecast[[;;,5]]]>-500,Max[forecast[[;;,5]]]<1000,
  Min[forecast[[;;,6]]]>0,Max[forecast[[;;,6]]]<5000,
  Min[forecast[[;;,7]]]>-100,Max[forecast[[;;,7]]]<100,
  Min[forecast[[;;,8]]]>=0.,Max[forecast[[;;,8]]]<300];
 c2=And[Min[obserH[[;;,1]]]>50000,Max[obserH[[;;,1]]]<150000,
  Min[obserH[[;;,2]]]>=0.,Max[obserH[[;;,2]]]<0.5,
  Min[obserH[[;;,3]]]>=0.,Max[obserH[[;;,3]]]<0.5,
  Min[obserH[[;;,4]]]>=0.,Max[obserH[[;;,4]]]<0.5,
  Min[obserH[[;;,5]]]>-500,Max[obserH[[;;,5]]]<1000,
  Min[obserH[[;;,6]]]>0,Max[obserH[[;;,6]]]<5000,
  Max[obserH[[;;,7]]]<100,Max[obserH[[;;,8]]]<900]; 
 If[Not[And[c1,c2]],
  Block[{},Print["problem "<>files[[i]]];
  CopyFile[files[[i]],"/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Paired/Problematic/"<>files[[i]]]]];
 {tempt["observation_H"],tempt["observation_L"],tempt["forecast"]}]
 ,{i,Length[files]}];
*)
forecast=Table[Block[{tempt,forecast,obserH,obseL},
 Print[files[[i]]];
 Import[files[[i]]]["forecast"]],{i,Length[files]}];
forecast=Flatten[Map[Normal,forecast],1];
meanvarforecast=Table[{Mean[forecast[[;;,var]]],Sqrt[Variance[forecast[[;;,var]]]]},{var,7}];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
obser=Normal[Import["obser.mx"]["data"]];
meanvarobser=Table[{Mean[obser[[;;,var]]],Sqrt[Variance[obser[[;;,var]]]]},{var,7}];

tobser=Table[Import["T_R"<>ToString[i]<>".mx"],{i,5}];
tobser=Map[#[["data"]]&,tobser];
meanvarT=Map[{Mean[Normal[#]],Sqrt[Variance[Normal[#]]]}&,tobser];

Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Normalization.mx",
          <|"meanvarforecast"->meanvarforecast,
            "meanvarobser"->meanvarobser,
            "meanvarT"->meanvarT,
            "var"-> {"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m"}|>];

(*
masks=Table[Block[{base},
 base=Table[If[meanvarT[[scale,-1]][[i,j]]==0.,0,1],{i,Dimensions[meanvarT[[scale,-1]]][[1]]},{j,Dimensions[meanvarT[[scale,-1]]][[2]]}]],{scale,5}];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Mask.mx",masks];
*)

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
Table[ToExpression["pR"<>ToString[i]<>"=Normal[Import[\"P_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];
masks=Block[{tempt={pR1,pR2,pR3,pR4,pR5}},
 tempt=Map[Mean,tempt];
 Table[Block[{base=tempt[[i]]/. x_ /; x>=0->1},base=base/.x_/;x<0->0],{i,Length[tempt]}]];
Export["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Mask.mx",masks];

Table[ToExpression["tR"<>ToString[i]<>"=Normal[Import[\"T_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];
masks=Block[{tempt={tR1,tR2,tR3,tR4,tR5}},
 tempt=Map[Mean,tempt];
 Table[Block[{base=tempt[[i]]/. x_ /; x>=-20->1},base=base/.x_/;x<-20->0],{i,Length[tempt]}]];
