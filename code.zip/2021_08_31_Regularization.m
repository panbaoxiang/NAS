var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem=NumericArray[{Log[Import["Elevation.mx"][[1]]+1.]},"Real32"];(*{368, 493}, 4km*4km*)
training=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/training.mx"][[;;,{1,3}]];
validation=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/validation.mx"][[;;,{1,3}]];
mask=Block[{tempt=Variance[Normal[training[[1,1,-1]]]]},
  NumericArray[Table[If[And[c>6,tempt[[i,j]]==0.],0,1],{c,8},{d,3},{i,Length[tempt]},{j,Dimensions[tempt][[2]]}],"Real32"]];
Import["/g/g92/pan11/CycleGAN_HD/RADA_Regularization.m"];

option=RandomSample[{<|"net"->pR,"set"->1,"channel"->"8","name"->"trained_p_simulation_regularization.mx"|>,
	<|"net"->pR,"set"->2,"channel"->"8","name"->"trained_p_observation_regularization.mx"|>,
        <|"net"->tR,"set"->1,"channel"->"7","name"->"trained_t_simulation_regularization.mx"|>,
        <|"net"->tR,"set"->2,"channel"->"7","name"->"trained_t_observation_regularization.mx"|>,
        <|"net"->yesterdayR,"set"->1,"channel"->";;,1","name"->"trained_yesterday_simulation_regularization.mx"|>,
        <|"net"->yesterdayR,"set"->2,"channel"->";;,1","name"->"trained_yesterday_observation_regularization.mx"|>,
        <|"net"->futureR,"set"->1,"channel"->";;,-1","name"->"trained_tomorrow_simulation_regularization.mx"|>,
        <|"net"->futureR,"set"->2,"channel"->";;,-1","name"->"trained_tomorrow_observation_regularization.mx"|>}][[1]];

Print[option["name"]];
        
choice=Hold[Block[{globe,Report,nn=option["net"],set=option["set"],channel=option["channel"],name=option["name"]},
{nn,globe}=If[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/Result/"<>name],Block[{tempt=Import["/usr/workspace/pan11/CycleGAN_HD/Result/"<>name]},{tempt["net"],tempt["mse"]}],{nn,Infinity}];
Report[net_]:=Block[{size=Length[validation],choice1,choice2,data,model,simu,obser,result},
  choice1=Range[size];
  choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,validation[[choice1]]];
  data=Table[<|"Input"->validation[[choice1[[i]],set]][[;;,choice2[[i]];;choice2[[i]]+2]],"Elevation"->dem,"Mask"->mask|>,{i,Length[choice1]}];
  model=NetTake[net,"thread"];
  simu=Map[model[#,TargetDevice->"GPU"]&,data];
  obser=Table[ToExpression["data[[i]][\"Input\"][["<>channel<>"]]"],{i,Length[data]}];
  {simu,obser}=Map[Normal,{simu,obser}];
  corr=Table[If[mask[[-1,1,j,k]]>0,Correlation[simu[[;;,i,j,k]],obser[[;;,i,j,k]]],Null],{i,Dimensions[obser][[2]]},{j,Dimensions[obser][[3]]},{k,Dimensions[obser][[4]]}];
  corr=Select[Flatten[corr],NumberQ];
  result=Mean[(Flatten[simu]-Flatten[obser])^2];
  Print[name];
  Print[{Mean[Flatten[corr]], MinMax[corr]}];
  Print[{globe,result}];
  If[result<globe,
     Block[{},
       Print["update"];
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/"<>name,<|"net"->net,"mse"->result|>];
       Set[globe,result]]]];
NetTrain[nn,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"Input"->Table[training[[choice1[[i]],set]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[mask,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  BatchSize -> 64,
  WorkingPrecision->"Real32",
  TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-4},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[300, "Batches"]},"Print"}];]];

ReleaseHold[choice];
