dir=Directory[];
files=Select[FileNames["slurm*"],UnitConvert[FileSize[#],"Kilobytes"][[1]]<6&];
Print[files];
head=Quiet[Map[Block[{content=Import[#,"Table"]},
  If[content[[1]]=={"No", "valid", "password", "found."},
	Block[{},Print[#<>" deleted"];	DeleteFile[#]]]]&,files]];
