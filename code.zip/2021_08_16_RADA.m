Import["/g/g92/pan11/CycleGAN_HD/2021_08_07_Regularization.m"];
S2O=Block[{outputS2O},
  outputS2O=NetInitialize[NetGraph[<|"part1"->{ConvolutionLayer[16,{1,1,1}],BatchNormalizationLayer[],Ramp,ConvolutionLayer[7,{1,1,1}]},
				  "part2"->{ConvolutionLayer[16,{1,1,1}],BatchNormalizationLayer[],Ramp,ConvolutionLayer[1,{1,1,1}],Ramp},
				  "append"->CatenateLayer[]|>,
	{NetPort["Input"]->"part1"->"append", 
	 NetPort["Input"]->"part2"->"append"}, 
    "Input"->dimO]];
  NetGraph[<|"upsample"->NetMapOperator[ResizeLayer[dimO[[3;;4]]]],
             "ele"->eleO,
             "blend"->CatenateLayer[],
             "blendpost"->ConvolutionLayer[8,{1,1,1}],
             "corrector"->{RO2S,outputS2O},
             "threading"->ThreadingLayer[Times]|>,
       {NetPort["GCM"]->"upsample",
        "blendpost"->"corrector"->"threading",
        NetPort["Mask"]->"threading",
        NetPort["Elevation"]->"ele"->"blend",
        "upsample"->"blend"->"blendpost"},
    "GCM"->dimS,
    "Mask"->dimO,
    "Elevation"->Dimensions[dem]]]

O2S=Block[{outputO2S},
 outputO2S=NetInitialize[NetGraph[<|"part1"->{ConvolutionLayer[16,{1,1,1}],BatchNormalizationLayer[],Ramp,ConvolutionLayer[7,{1,1,1}]},
				  "part2"->{ConvolutionLayer[16,{1,1,1}],BatchNormalizationLayer[],Ramp,ConvolutionLayer[1,{1,1,1}],Ramp},
				  "append"->CatenateLayer[]|>,
	{NetPort["Input"]->"part1"->"append", 
	 NetPort["Input"]->"part2"->"append"}, 
 "Input"->dimS]];
 NetGraph[<|"downsample"->{ConvolutionLayer[8,{1,2,2},"Stride"->{1,2,2},"PaddingSize"->{0,1,1}]},
            "ele"->ele,
            "blend"->CatenateLayer[],
            "blendpost"->ConvolutionLayer[8,{1,1,1}],
            "corrector"->{RS2O,outputO2S},
            "threading"->ThreadingLayer[Times]|>,
       {NetPort["Obser"]->"downsample"->"blend",
        NetPort["Elevation"]->"ele"->"blend"->"blendpost",
        "blendpost"->"corrector"->"threading",
        NetPort["Mask"]->"threading"},
    "Obser"->dimO,
    "Mask"->dimS]]

DO2S=NetChain[{ConvolutionLayer[16,{3,3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   FlattenLayer[1],
			   ConvolutionLayer[16,{3,3},"Stride"->2],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   FlattenLayer[],
			   1
			   },
	"Input"->dimS];

DS2O=NetChain[{ConvolutionLayer[16,{3,3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   FlattenLayer[1],
			   ConvolutionLayer[16,{3,3},"Stride"->2],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3},"Stride"->2],
			   BatchNormalizationLayer[],
			   FlattenLayer[],
			   1
			   },
	"Input"->dimO];


S2Of = NetInsertSharedArrays[S2O, "S2O/"];
S2Ob = NetInsertSharedArrays[S2O, "S2O/"];

O2Sf = NetInsertSharedArrays[O2S, "O2S/"];
O2Sb = NetInsertSharedArrays[O2S, "O2S/"];



RADA=NetInitialize[NetGraph[<|
		   "S2Of"->S2Of,
		   "O2Sf"->O2Sf,
		   "DS2O"->NetMapOperator[DS2O],
		   "DO2S"->NetMapOperator[DO2S],
		   
           "Cat_S2O"->CatenateLayer[],
           "Reshape_S2O" -> ReshapeLayer[Prepend[dimO,2]],
           "Flat_S2O" -> ReshapeLayer[{2}],
           "Fake_S2O"->PartLayer[1],
           "Real_S2O"->PartLayer[2],
           "Scale_S2O" -> ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0],
           
           "Cat_O2S"->CatenateLayer[],
           "Reshape_O2S" -> ReshapeLayer[Prepend[dimS,2]],
           "Flat_O2S" -> ReshapeLayer[{2}],
           "Fake_O2S"->PartLayer[1],
           "Real_O2S"->PartLayer[2],
           "Scale_O2S" -> ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0],
		   
		   "O2Sb"->O2Sb,
		   "S2Ob"->S2Ob,
		   "MSE_S2O2S"->MeanAbsoluteLossLayer[],
		   "MSE_O2S2O"->MeanAbsoluteLossLayer[]
		   |>,
 {NetPort["S"]->NetPort["S2Of","GCM"],
  NetPort["Elevation"]->NetPort["S2Of","Elevation"],
  NetPort["MaskO"]->NetPort["S2Of","Mask"],
  "S2Of"->"Cat_S2O",
  NetPort["O"]->"Cat_S2O",
  "Cat_S2O"->"Reshape_S2O"->"DS2O"->"Flat_S2O"->"Scale_S2O",
  "Scale_S2O"->"Fake_S2O"->NetPort["Fake_S2O"],
  "Scale_S2O"->"Real_S2O"->NetPort["Real_S2O"],
  
  NetPort["O"]->NetPort["O2Sf","Obser"],
  NetPort["MaskS"]->NetPort["O2Sf","Mask"],
  NetPort["Elevation"]->NetPort["O2Sf","Elevation"],
  "O2Sf"->"Cat_O2S",
  NetPort["S"]->"Cat_O2S",
  "Cat_O2S"->"Reshape_O2S"->"DO2S"->"Flat_O2S"->"Scale_O2S",
  "Scale_O2S"->"Fake_O2S"->NetPort["Fake_O2S"],
  "Scale_O2S"->"Real_O2S"->NetPort["Real_O2S"],
  
  "S2Of"->NetPort["O2Sb","Obser"],
  NetPort["MaskS"]->NetPort["O2Sb","Mask"],
  NetPort["Elevation"]->NetPort["O2Sb","Elevation"],
  "O2Sb"->"MSE_S2O2S",
  NetPort["S"]->"MSE_S2O2S"->NetPort["Cycle_S2O"],
  
  "O2Sf"->NetPort["S2Ob","GCM"],
  NetPort["MaskO"]->NetPort["S2Ob","Mask"],
  NetPort["Elevation"]->NetPort["S2Ob","Elevation"],
  "S2Ob"->"MSE_O2S2O",
  NetPort["O"]->"MSE_O2S2O"->NetPort["Cycle_O2S"]
  }]]

training=Map[{NumericArray[#[[1]],"Real32"],NumericArray[#[[2]],"Real32"]}&,training];
dem=NumericArray[dem,"Real32"];
maskS=NumericArray[maskS,"Real32"];
maskO=NumericArray[maskO,"Real32"];

globe=Infinity;
index=StringSplit[CreateUUID[],"-"][[1]];
Report[net_]:=Block[{n1=10,n2=10,choice1,choice2,data,model,correction,obser,energy},
  choice1=RandomSample[Range[Length[validation]],n1];
  choice2=Table[RandomSample[Range[Dimensions[validation[[q,2]]][[2]]-2]][[1;;n2]],{q,choice1}];
  data=Flatten[Table[<|"S"->validation[[choice1[[i]],1]][[;;,choice2[[i,j]];;choice2[[i,j]]+2]],
               "O"->validation[[choice1[[i]],2]][[;;,choice2[[i,j]];;choice2[[i,j]]+2]],
	       "Elevation"->dem,
               "Mask"->mask]|>,{i,n1},{j,n2}],1];
  model=NetTake[net,"S2Of"];
  correction=Map[model[#,TargetDevice->"GPU"]&,data[[;;,{1,3,4}]]];
  obser=data[[;;,2]];
  correction=Map[Flatten,correction];
  obser=Map[Flatten,obser];
  energy=2*Total[Flatten[Table[EuclideanDistance[correction[[i]],obser[[j]]],{i,Length[correction]},{j,Length[obser]}]]]-
	Total[Flatten[Table[EuclideanDistance[correction[[i]],correction[[j]]],{i,Length[correction]},{j,Length[correction]}]]]-
        Total[Flatten[Table[EuclideanDistance[obser[[i]],obser[[j]]],{i,Length[obser]},{j,Length[obser]}]]];
  Print["energy value"];
  Print[index];
  Print[{globe,energy}];
  If[energy<globe,
     Block[{},
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/trained_RADA_"<>index<>".mx",net];
       Set[globe,energy]]]];

NetTrain[RADA,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"S"->Table[training[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "O"->Table[training[[choice1[[i]],2]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[mask,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  LossFunction ->{"Fake_S2O"->Scaled[3],"Real_S2O"->Scaled[3],"Cycle_S2O"->Scaled[-1],
                  "Fake_O2S"->Scaled[3],"Real_O2S"->Scaled[3],"Cycle_O2S"->Scaled[-1]},
  TrainingUpdateSchedule -> {"DS2O"|"DO2S",
                             "O2Sf"|"S2Of",
                             "O2Sb"|"S2Ob"},
  LearningRateMultipliers -> {"DS2O"->1,"DO2S"->1,
                              "O2Sf"->-1,"S2Of"->-1,
                              "O2Sb"->-1,"S2Ob"->-1,
                              "Scale_S2O"->0,"Scale_O2S"->0},
  BatchSize -> 64,
  TargetDevice->{"GPU",1},
  WorkingPrecision->"Real32",
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-4,
	"WeightClipping" -> {"DS2O"-> 0.05,"DO2S"->0.05,_->3}},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[100, "Batches"]},"Print"}];
