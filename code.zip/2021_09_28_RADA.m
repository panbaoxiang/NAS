{s1,s2,s3,s4,s5}={4,4,4,10,2};
Print[{s1,s2,s3,s4,s5}];
vars={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
data=Import["data.mx"];
dem=Block[{raw=NumericArray[{Log[Import["Support/Elevation.mx"][[1]]+1.]},"Real32"](*{368, 493}, 4km*4km*),net1,net2,net3},
 net1=NetTake[Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/P_Downscaling.mx"],"ele"];
 net2=NetTake[Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/T_Downscaling.mx"],"ele"];
 NumericArray[Transpose[Table[Flatten[Normal[{net1[raw],net2[raw]}],1],{3}]],"Real32"]];
mask=Block[{mask=Import["Support/Mask.mx"][[1]]},
	NumericArray[Transpose[Table[Join[ConstantArray[1,Prepend[Dimensions[mask],6]],Table[mask,2]],3]],"Real32"]];
dates=data[["dates"]];

ptraining=Position[dates[[;;,1]],_?(MemberQ[{1982,1990,1991,2000,2001,2010,2011},#]&)][[;;,1]];
pvalidation=Position[dates[[;;,1]],_?(MemberQ[{1992,2002,2012},#]&)][[;;,1]];
Import["/g/g92/pan11/CycleGAN_HD/RADA_Ceiling.m"];

index=StringSplit[CreateUUID[],"-"][[1]];
globe=0;
choice=Flatten[Table[Position[dates,RandomSample[Select[dates[[pvalidation]],#[[1;;2]]=={year,month}&]][[1]]][[1,1]],{year,{1992,2002,2012}},{month,12}]];
length=Min[Map[Length,data[[1,choice,1]]]]-2;
tempt=Table[<|"S"->Map[Transpose,data[[1,choice,1,i;;i+2]]],
                "O"->Map[Transpose,data[[1,choice,2,i;;i+2]]],
                "Elevation"->Table[dem,Length[choice]],
                "Mask"->Table[mask,Length[choice]]|>,{i,length}];
obser=tempt[[;;,"O"]];
raw=tempt[[;;,"S"]];
obser=Table[Normal[obser[[;;,member]][[;;,-2;;-1,2]]],{member,Dimensions[obser][[2]]}];
raw=Table[Normal[raw[[;;,member]][[;;,-2;;-1,2]]],{member,Dimensions[raw][[2]]}];
energyraw=Table[Block[{e=2*Total[Flatten[Table[EuclideanDistance[Flatten[obser[[member,i]]],Flatten[raw[[member,j]]]],{i,length},{j,length}]]]-
        Total[Flatten[Table[EuclideanDistance[Flatten[raw[[member,i]]],Flatten[raw[[member,j]]]],{i,length},{j,length}]]]-
        Total[Flatten[Table[EuclideanDistance[Flatten[obser[[member,i]]],Flatten[obser[[member,j]]]],{i,length},{j,length}]]]},
	Print[dates[[choice[[member]]]]];
	Print[e];e],{member,Length[choice]}];

Report[net_]:=Block[{model,correction},
  model=NetTake[net,"S2Of"];
  correction=Map[model[<|"S"->#[["S"]],"Elevation"->#[["Elevation"]],"Mask"->#[["Mask"]]|>,TargetDevice->{"GPU",2}]&,tempt];
  correction=Table[Normal[correction[[;;,member]][[;;,-2;;-1,2]]],{member,Dimensions[correction][[2]]}];
  Print[{{"max obser T","max raw T","max correction T"},
         {Max[obser[[;;,;;,1]]],Max[raw[[;;,;;,1]]],Max[correction[[;;,;;,1]]]},
         {"max obser P","max raw P","max correction P"},
         {Max[Exp[obser[[;;,;;,2]]]],Max[Exp[raw[[;;,;;,2]]]],Max[Exp[correction[[;;,;;,2]]]]}}];
  If[And[Max[correction[[;;,;;,1]]]<=Max[obser[[;;,;;,1]]]*1.2,Max[Exp[correction[[;;,;;,2]]]]<=Max[Exp[obser[[;;,;;,2]]]]*1.2,Max[correction[[;;,;;,1]]]>=Max[obser[[;;,;;,1]]]*.8,Max[Exp[correction[[;;,;;,2]]]]>=Max[Exp[obser[[;;,;;,2]]]]*.8],
  Block[{energy, gain},
  Print["Yes"];
  energy=Table[Block[{e=2*Total[Flatten[Table[EuclideanDistance[Flatten[obser[[member,i]]],Flatten[correction[[member,j]]]],{i,length},{j,length}]]]-
        Total[Flatten[Table[EuclideanDistance[Flatten[correction[[member,i]]],Flatten[correction[[member,j]]]],{i,length},{j,length}]]]-
        Total[Flatten[Table[EuclideanDistance[Flatten[obser[[member,i]]],Flatten[obser[[member,j]]]],{i,length},{j,length}]]]},
        Print[dates[[choice[[member]]]]];
        Print[{"before","after"}];
        Print[{energyraw[[member]],e}];e],{member,Length[choice]}]; 
  Print["globe\t energy value after\t energy value before"];
  Print[index];
  gain=Total[energy]-Total[energyraw];
  Print[{energy,energyraw}];
  Print[{globe,Total[energy],Total[energyraw],gain}];
  If[gain<globe,
     Block[{},
      	 Print["Update"];
      	 Export["/usr/workspace/pan11/CycleGAN_HD/Result/RADA_Exp_"<>index<>"_"<>StringRiffle[Map[ToString,{s1,s2,s3,s4,s5}],"_"]<>".mx",net];
       	 Set[globe,gain]]]]]];

NetTrain[RADA,
 {Function[Block[{choice1,choice2,choice3},
   choice1=RandomSample[Range[Length[data[[1]]]],#BatchSize];
   choice2=Map[RandomSample[Range[#-2]][[1]]&, Map[Length,data[[1,choice1]][[;;,1]]]];
   choice3=Table[Block[{tem=choice2[[i]]+RandomSample[Range[-15,15]][[1]]},If[tem<=Length[data[[1,choice1[[i]]]][[1]]]-2,If[tem>0,tem,1],Length[data[[1,choice1[[i]]]][[1]]]-2]],{i,#BatchSize}];
   <|"S"->Table[Transpose[data[[1,choice1[[i]],1,choice2[[i]];;choice2[[i]]+2]]],{i,#BatchSize}],
     "O"->Table[Transpose[data[[1,choice1[[i]],2,choice3[[i]];;choice3[[i]]+2]]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[mask,{i,#BatchSize}]|>]],"RoundLength" -> Length[data[[1]]]*100},
  LossFunction ->{"Fake_S2O"->Scaled[s1],"Real_S2O"->Scaled[s1],"Cycle_S2O"->Scaled[-s2],
                  "Fake_O2S"->Scaled[s1],"Real_O2S"->Scaled[s1],"Cycle_O2S"->Scaled[-s2],
		  "Fake_S2O_prmsl"->Scaled[s1],"Real_S2O_prmsl"->Scaled[s1],
		  "Fake_S2O_p"->Scaled[s1],"Real_S2O_p"->Scaled[s1],
		  "Fake_S2O_t2m"->Scaled[s1],"Real_S2O_t2m"->Scaled[s1],
		  "Fake_S2O_q925"->Scaled[s1],"Real_S2O_q925"->Scaled[s1],
		  "Fake_S2O_z1000"->Scaled[s1],"Real_S2O_z1000"->Scaled[s1],
                  "Fake_O2S_prmsl"->Scaled[s1],"Real_O2S_prmsl"->Scaled[s1],
                  "Fake_O2S_p"->Scaled[s1],"Real_O2S_p"->Scaled[s1],
                  "Fake_O2S_t2m"->Scaled[s1],"Real_O2S_t2m"->Scaled[s1],
                  "Fake_O2S_q925"->Scaled[s1],"Real_O2S_q925"->Scaled[s1],
                  "Fake_O2S_z1000"->Scaled[s1],"Real_O2S_z1000"->Scaled[s1],
                  "Loss_Self_S2O"->Scaled[-s3],"Loss_Self_O2S"->Scaled[-s3],
		  "Loss_pR_O"->Scaled[-s4],"Loss_pR_S"->Scaled[-s4],
		  "Loss_tR_O"->Scaled[-s4],"Loss_tR_S"->Scaled[-s4],
		  "Loss_yesterdayR_O"->Scaled[-s4],"Loss_yesterdayR_S"->Scaled[-s4],
		  "Loss_tomorrowR_O"->Scaled[-s4],"Loss_tomorrowR_S"->Scaled[-s4]},
  TrainingUpdateSchedule -> {"DS2O"|"DO2S",
			     "DS2Oprmsl"|"DO2Sprmsl",
			     "DS2Op"|"DO2Sp",
			     "DS2Ot2m"|"DO2St2m",
			     "DS2Oq925"|"DO2Sq925",
			     "DS2Oz1000"|"DO2Sz1000",
                             "O2Sf"|"S2Of",
                             "O2Ss"|"S2Os",
                             "O2Sb"|"S2Ob"},
  LearningRateMultipliers -> {"DS2O"->1,"DO2S"->1,
			      "DS2Oprmsl"->1,"DO2Sprmsl"->1,
			      "DS2Op"->1,"DO2Sp"->1,
			      "DS2Ot2m"->1,"DO2St2m"->1,
			      "DS2Oq925"->1,"DO2Sq925"->1,
			      "DS2Oz1000"->1,"DO2Sz1000"->1,
                              "O2Sf"->-1,"S2Of"->-1,
                              "O2Sb"->-1,"S2Ob"->-1,
                              "O2Ss"->-1,"S2Os"->-1,
			      "pR_S"->0,"pR_O"->0,
                              "tR_S"->0,"tR_O"->0,
			      "yesterdayR_S"->0,"yesterdayR_O"->0,
			      "tomorrowR_S"->0,"tomorrowR_O"->0,_->0},
  BatchSize -> 64,
  TargetDevice->{"GPU",1},
  WorkingPrecision->"Real32",
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-3,
        "WeightClipping" -> {"DS2O"-> s5/32.,"DO2S"->s5/32.,
			     "DS2Oprmsl"->s5/32.,"DO2Sprmsl"->s5/32.,
                             "DS2Op"->s5/32.,"DO2Sp"->s5/32.,
                             "DS2Ot2m"->s5/32.,"DO2St2m"->s5/32.,
                             "DS2Oq925"->s5/32.,"DO2Sq925"->s5/32.,
                             "DS2Oz1000"->s5/32.,"DO2Sz1000"->s5/32.,
                              _->1}},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[100, "Batches"]},"Print"}];
