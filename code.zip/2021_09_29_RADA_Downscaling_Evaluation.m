SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/"];
files=FileNames["*mx"];
regions={"SCal","NCal","Nevada","Washington","NRocky","Oregon","Wasatch","Colorado"};
Table[Block[{data,result},
data=Import[files[[i]]];
result=Table[Block[{points},
Print[regions[[region]]];
points=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Polyon/"<>regions[[region]]<>"_grid.mx"][[1]];
{Praw,Pcorrection,Pobser,Traw,Tcorrection,Tobser}=Map[data[#]&,{"hPraw","hPcorrection", "hPobser","hTraw", "hTcorrection", "hTobser"}];
{sPraw,sPcorrection,sPobser,sTraw,sTcorrection,sTobser}=Map[Block[{data=#},Table[NumericArray[Mean[Normal[Map[data[[i]][[;;,#[[1]],#[[2]]]]&,points[[i]]]]],"Real32"],{i,Length[points]}]]&,{Praw,Pcorrection,Pobser,Traw,Tcorrection,Tobser}];
Print[Map[Map[Mean[Normal[#]]&,#]&,{sPraw,sPcorrection,sPobser}]];
Print[Map[Map[Mean[Normal[#]]&,#]&,{sTraw,sTcorrection,sTobser}]];
{sPraw,sPcorrection,sPobser,sTraw,sTcorrection,sTobser}],{region,Length[regions]}];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/Summary/"<>files[[i]],
 result]],{i,Length[files]}];
