obser=Normal[Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/obser.mx"]["data_L"]];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
Table[ToExpression["tR"<>ToString[i]<>"=Normal[Import[\"T_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];

meanvar=Block[{data={tR1,tR2,tR3,tR4,tR5}},
 Table[Block[{mean,var,tempt},
  mean=Mean[data[[i]]];
  var=Sqrt[Variance[data[[i]]]];
  {mean,var+10^-6}],{i,5}]];

masks=Table[Block[{mt=Mean[Normal[ToExpression["tR"<>ToString[ii]]]],position},
  position=Table[If[mt[[i,j]]>-100,1,0],{i,Length[mt]},{j,Dimensions[mt][[2]]}];
  position],{ii,5}];
{tR1,tR2,tR3,tR4,tR5}=Block[{data={tR1,tR2,tR3,tR4,tR5}},
 Table[Block[{mean,var,tempt},
  mean=Mean[data[[i]]];
  var=Sqrt[Variance[data[[i]]]];
  tempt=Map[(#-mean)/(var+10^-6)&,data[[i]]];
  Map[#*masks[[i]]&,tempt]],{i,5}]];
{tR1,tR2,tR3,tR4,tR5}=Map[#[[1;;Length[obser]]]&,{tR1,tR2,tR3,tR4,tR5}];

data=Block[{meanvar,tempt,p},
 meanvar=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Normalization.mx"]["meanvarobser_L"];
 tempt=Table[Map[(#-meanvar[[i,1]])/(meanvar[[i,2]]+10^-6)&,obser[[;;,i]]],{i,7}];
 tempt=Transpose[Join[tempt,{tR1}]];
 Table[<|"Input"->tempt[[i]],
         "Output_R1"->{tR2[[i]]},
         "Output_R2"->{tR3[[i]]},
         "Output_R3"->{tR4[[i]]},
         "Output_R4"->{tR5[[i]]}|>,{i,Length[tempt]}]];

ele=Block[{tempt=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Elevation.mx"]["Elevation"]},
 tempt=(tempt /. x_ /; x<-0.->0);
 {Log[tempt+1.]}];


test=Range[Round[Length[data]*0.85],Length[data]];
testset= Table[<|"Input"->data[[i,"Input"]],
   "Mask1"->{masks[[2]]},
   "Output_R1"->data[[i,"Output_R1"]],
   "Mask2"->{masks[[3]]},
   "Output_R2"->data[[i,"Output_R2"]],
   "Mask3"->{masks[[4]]},
   "Output_R3"->data[[i,"Output_R3"]],
   "Mask4"->{masks[[5]]},
   "Output_R4"->data[[i,"Output_R4"]],
   "Elevation"->ele|>,{i,test}];

  
net=Import["/usr/workspace/pan11/CycleGAN_HD/Result/T_Downscaling.mx"];
simu=Map[net[#,TargetDevice->"GPU"]&,testset[[;;,{"Input","Mask1","Mask2","Mask3","Mask4","Elevation"}]]];
obser=obser=testset[[;;,{"Output_R1","Output_R2","Output_R3","Output_R4"}]];


Table[Set[simu[[;;,i]],Map[#*{meanvar[[i+1,2]]}+{meanvar[[i+1,1]]}&,simu[[;;,i]]]],{i,4}];
Table[Set[obser[[;;,i]],Map[#*{meanvar[[i+1,2]]}+{meanvar[[i+1,1]]}&,obser[[;;,i]]]],{i,4}];


corr=Table[Block[{s=simu[[;;,"Output_R"<>ToString[i]]],o=testset[[;;,"Output_R"<>ToString[i]]]},
   Table[If[Variance[s[[;;,1,a,b]]]==0,-1,Correlation[s[[;;,1,a,b]],o[[;;,1,a,b]]]],{a,Dimensions[s][[3]]},{b,Dimensions[s][[4]]}]],{i,4}];
summary=Map[Mean[Select[Flatten[#],#>-.4&]]&,corr];
Print[summary];

Export["/usr/workspace/pan11/CycleGAN_HD/Result/T_Downscaling_Result.mx",
  <|"simu"->simu,
    "obser"->obser,
    "date"->DatePlus[{1981,12,31},Round[Length[data]*0.85]]|>];
