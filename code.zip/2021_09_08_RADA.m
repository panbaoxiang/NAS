{s1,s2,s3,s4,s5}=Table[RandomSample[{1,2,4,8,16,32}][[1]],{5}];
{s1,s2,s3,s4,s5}={4,4,4,4,4};
Print[{s1,s2,s3,s4,s5}];
vars={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem=NumericArray[{Log[Import["Elevation.mx"][[1]]+1.]},"Real32"];(*{368, 493}, 4km*4km*)
training=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/training.mx"][[;;,{1,3}]];
validation=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/validation.mx"][[;;,{1,3}]];
mask=Block[{tempt=Variance[Normal[training[[1,1,-1]]]]},
  NumericArray[Table[If[And[c>6,tempt[[i,j]]==0.],0,1],{c,8},{d,3},{i,Length[tempt]},{j,Dimensions[tempt][[2]]}],"Real32"]];
Import["/g/g92/pan11/CycleGAN_HD/RADA_V2.m"];


globe=Infinity;
index=StringSplit[CreateUUID[],"-"][[1]];
Report[net_]:=Block[{n1=20,n2=20,choice1,choice2,data,model,correction,obser,energy,energyraw,gain},
  choice1=RandomSample[Range[Length[validation]],n1];
  choice2=Table[RandomSample[Range[Dimensions[validation[[q,2]]][[2]]-2]][[1;;n2]],{q,choice1}];
  data=Flatten[Table[<|"S"->validation[[choice1[[i]],1]][[;;,choice2[[i,j]];;choice2[[i,j]]+2]],
               "O"->validation[[choice1[[i]],2]][[;;,choice2[[i,j]];;choice2[[i,j]]+2]],
               "Elevation"->dem,
               "Mask"->mask|>,{i,n1},{j,n2}],1];
  model=NetTake[net,"S2Of"];
  correction=Map[model[<|"S"->#[["S"]],"Elevation"->#[["Elevation"]],"Mask"->#[["Mask"]]|>,TargetDevice->"GPU"]&,data];
  obser=data[[;;,"O"]];
  raw=data[[;;,"S"]];
  {correction,obser,raw}=Map[Normal,{correction,obser,raw}];
  Print[MinMax[correction]];
  If[Max[Abs[correction]]<Max[Abs[obser]]*3,
  correction=Map[Flatten,correction];
  obser=Map[Flatten,obser];
  raw=Map[Flatten,raw];
  energy=2*Total[Flatten[Table[EuclideanDistance[correction[[i]],obser[[j]]],{i,Length[correction]},{j,Length[obser]}]]]-
        Total[Flatten[Table[EuclideanDistance[correction[[i]],correction[[j]]],{i,Length[correction]},{j,Length[correction]}]]]-
        Total[Flatten[Table[EuclideanDistance[obser[[i]],obser[[j]]],{i,Length[obser]},{j,Length[obser]}]]];
  energyraw=2*Total[Flatten[Table[EuclideanDistance[raw[[i]],obser[[j]]],{i,Length[correction]},{j,Length[obser]}]]]-
        Total[Flatten[Table[EuclideanDistance[raw[[i]],raw[[j]]],{i,Length[correction]},{j,Length[correction]}]]]-
        Total[Flatten[Table[EuclideanDistance[obser[[i]],obser[[j]]],{i,Length[obser]},{j,Length[obser]}]]];
  Print["globe\t energy value after\t energy value before"];
  Print[index];
  gain=energy-energyraw;
  Print[{globe,energy,energyraw,gain}];
  If[gain<globe,
     Block[{},
       Print["Update"];
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/RADA_"<>index<>"_"<>StringRiffle[Map[ToString,{s1,s2,s3,s4,s5}],"_"]<>".mx",net];
       Set[globe,gain]]]]];

NetTrain[RADA,
 {Function[Block[{choice1,choice2},
   choice1=RandomSample[Range[Length[training]],#BatchSize];
   choice2=Map[RandomSample[Range[Dimensions[#[[1]]][[2]]-2]][[1]]&,training[[choice1]]];
   <|"S"->Table[training[[choice1[[i]],1]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "O"->Table[training[[choice1[[i]],2]][[;;,choice2[[i]];;choice2[[i]]+2]],{i,#BatchSize}],
     "Elevation"->Table[dem,{i,#BatchSize}],
     "Mask"->Table[mask,{i,#BatchSize}]|>]],"RoundLength" -> Length[training]*300},
  LossFunction ->{"Fake_S2O"->Scaled[s1],"Real_S2O"->Scaled[s1],"Cycle_S2O"->Scaled[-s2],
                  "Fake_O2S"->Scaled[s1],"Real_O2S"->Scaled[s1],"Cycle_O2S"->Scaled[-s2],
		  "Fake_S2O_prmsl"->Scaled[s1],"Real_S2O_prmsl"->Scaled[s1],
		  "Fake_S2O_p"->Scaled[s1],"Real_S2O_p"->Scaled[s1],
		  "Fake_S2O_t2m"->Scaled[s1],"Real_S2O_t2m"->Scaled[s1],
		  "Fake_S2O_q925"->Scaled[s1],"Real_S2O_q925"->Scaled[s1],
		  "Fake_S2O_z1000"->Scaled[s1],"Real_S2O_z1000"->Scaled[s1],
                  "Fake_O2S_prmsl"->Scaled[s1],"Real_O2S_prmsl"->Scaled[s1],
                  "Fake_O2S_p"->Scaled[s1],"Real_O2S_p"->Scaled[s1],
                  "Fake_O2S_t2m"->Scaled[s1],"Real_O2S_t2m"->Scaled[s1],
                  "Fake_O2S_q925"->Scaled[s1],"Real_O2S_q925"->Scaled[s1],
                  "Fake_O2S_z1000"->Scaled[s1],"Real_O2S_z1000"->Scaled[s1],
                  "Loss_Self_S2O"->Scaled[-s3],"Loss_Self_O2S"->Scaled[-s3],
		  "Loss_pR_O"->Scaled[-s4],"Loss_pR_S"->Scaled[-s4],
		  "Loss_tR_O"->Scaled[-s4],"Loss_tR_S"->Scaled[-s4],
		  "Loss_yesterdayR_O"->Scaled[-s4],"Loss_yesterdayR_S"->Scaled[-s4],
		  "Loss_tomorrowR_O"->Scaled[-s4],"Loss_tomorrowR_S"->Scaled[-s4]},
  TrainingUpdateSchedule -> {"DS2O"|"DO2S",
			     "DS2Oprmsl"|"DO2Sprmsl",
			     "DS2Op"|"DO2Sp",
			     "DS2Ot2m"|"DO2St2m",
			     "DS2Oq925"|"DO2Sq925",
			     "DS2Oz1000"|"DO2Sz1000",
                             "O2Sf"|"S2Of",
                             "O2Ss"|"S2Os",
                             "O2Sb"|"S2Ob"},
  LearningRateMultipliers -> {"DS2O"->1,"DO2S"->1,
			      "DS2Oprmsl"->1,"DO2Sprmsl"->1,
			      "DS2Op"->1,"DO2Sp"->1,
			      "DS2Ot2m"->1,"DO2St2m"->1,
			      "DS2Oq925"->1,"DO2Sq925"->1,
			      "DS2Oz1000"->1,"DO2Sz1000"->1,
                              "O2Sf"->-1,"S2Of"->-1,
                              "O2Sb"->-1,"S2Ob"->-1,
                              "O2Ss"->-1,"S2Os"->-1,
			      "pR_S"->0,"pR_O"->0,
                              "tR_S"->0,"tR_O"->0,
			      "yesterdayR_S"->0,"yesterdayR_O"->0,
			      "tomorrowR_S"->0,"tomorrowR_O"->0},
  BatchSize -> 64,
  TargetDevice->{"GPU",1},
  WorkingPrecision->"Real32",
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> 10^-4,
        "WeightClipping" -> {"DS2O"-> s5/32.,"DO2S"->s5/32.,
			     "DS2Oprmsl"->s5/32.,"DO2Sprmsl"->s5/32.,
                             "DS2Op"->s5/32.,"DO2Sp"->s5/32.,
                             "DS2Ot2m"->s5/32.,"DO2St2m"->s5/32.,
                             "DS2Oq925"->s5/32.,"DO2Sq925"->s5/32.,
                             "DS2Oz1000"->s5/32.,"DO2Sz1000"->s5/32.,
                              _->1}},
  TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[100, "Batches"]},"Print"}];
