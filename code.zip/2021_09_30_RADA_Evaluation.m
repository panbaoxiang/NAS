month=7;
vars={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
data=Import["data.mx"];
dem=Block[{raw=NumericArray[{Log[Import["Support/Elevation.mx"][[1]]+1.]},"Real32"](*{368, 493}, 4km*4km*),net1,net2,net3},
 net1=NetTake[Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/P_Downscaling.mx"],"ele"];
 net2=NetTake[Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/T_Downscaling.mx"],"ele"];
 NumericArray[Transpose[Table[Flatten[Normal[{net1[raw],net2[raw]}],1],{3}]],"Real32"]];
mask=Block[{mask=Import["Support/Mask.mx"][[1]]},
	NumericArray[Transpose[Table[Join[ConstantArray[1,Prepend[Dimensions[mask],6]],Table[mask,2]],3]],"Real32"]];
dates=data[["dates"]];
meanvar=Import["Support/Normalization.mx"]["meanvarobser"][[-1]]*Normal[mask[[-2,1;;2]]];

ptraining=Position[dates[[;;,1]],_?(MemberQ[{1982,1990,1991,2000,2001,2010,2011},#]&)][[;;,1]];
pvalidation=Position[dates[[;;,1]],_?(MemberQ[{1992,2002,2012},#]&)][[;;,1]];
testyear=Flatten[{Range[1983,1989],Range[1993,1999],Range[2003,2009],Range[2013,2019]}];
testyear=Flatten[{Range[1983,1989],Range[1992,1999],Range[2002,2009],Range[2012,2019]}];
testyear=Range[1982,2019];
ptest=Intersection[Position[dates[[;;,1]],_?(MemberQ[testyear,#]&)][[;;,1]],Position[dates[[;;,2]],7][[;;,1]]];
testdates=dates[[ptest]];

startend=Table[{DateDifference[testdates[[i,1;;3]],{testdates[[i,1]],10,1}][[1]],DateDifference[testdates[[i,1;;3]],{testdates[[i,1]]+1,3,31}][[1]]},{i,Length[testdates]}];
test=Table[data[[1]][[ptest[[i]]]][[;;,startend[[i,1]]-1;;startend[[i,1]]+183]],{i,Length[startend]}];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/July.mx",
  <|"data"->test,
    "dates"->testdates|>];


models=Map[NetTake[Import[#],"S2Of"]&,FileNames["/usr/workspace/pan11/CycleGAN_HD/Result/RADA*mx"]];
result=Table[Block[{correction,obser,raw,mcorrection},
 Print[i];
 correction=Normal[Table[models[[k]][<|"S"->Table[Transpose[test[[i,1]][[j;;j+2]]],{j,183}],"Elevation"->Table[dem,183],"Mask"->Table[mask,183]|>,TargetDevice->"GPU"],{k,Length[models]}]][[;;,;;,;;,2]];
 obser=Normal[Table[Transpose[test[[i,2]][[j;;j+2]]],{j,183}][[;;,;;,2]]];
 raw=Normal[Table[Transpose[test[[i,1]][[j;;j+2]]],{j,183}][[;;,;;,2]]];
 mcorrection=NumericArray[Mean[correction],"Real32"];
 obser=NumericArray[obser,"Real32"];
 raw=NumericArray[raw,"Real32"];
 {obser,raw,mcorrection}],{i,Length[test]}];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/correction.mx",
 <|"obser"->result[[;;,1]],
   "raw"->result[[;;,2]],
   "correction"->result[[;;,3]]|>];






pDownscaling=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/P_Downscaling.mx"];
ele=Block[{tempt=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Elevation.mx"]["Elevation"]},
 tempt=(tempt /. x_ /; x<-0.->0);
 NumericArray[{Log[tempt+1.]},"Real32"]];
masks=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Mask.mx"];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
Table[ToExpression["pR"<>ToString[i]<>"=Normal[Import[\"P_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];

testdates=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/July.mx"][["dates"]];
result=Transpose[Values[Import["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/correction.mx"]]];
length=Length[result[[1,1]]];

Table[
If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/P/"<>DateString[testdates[[i]],{"Year","_","Month","_","Day","_","Hour",".mx"}]]],
Block[{pRaw,pCorrection,pObser},
Print[testdates[[i]]];
pRaw=Block[{tempt=pDownscaling[<|"Input"->result[[i,2]],
			      "Mask1"->Table[{masks[[2]]},Length[result[[i,2]]]],
			      "Mask2"->Table[{masks[[3]]},Length[result[[i,2]]]],
			      "Mask3"->Table[{masks[[4]]},Length[result[[i,2]]]],
			      "Mask4"->Table[{masks[[5]]},Length[result[[i,2]]]],
			      "Elevation"->Table[ele,Length[result[[i,1]]]]|>,TargetDevice->{"GPU",2}]},
    tempt=Map[Normal[#[[;;,1]]]&,Values[tempt]];
    tempt=Prepend[tempt,Normal[result[[i,2]][[;;,-1]]]];
    Map[NumericArray[Exp[#]-1.,"Real32"]&,tempt]];

pCorrection=Block[{tempt=pDownscaling[<|"Input"->result[[i,3]],
                              "Mask1"->Table[{masks[[2]]},Length[result[[i,2]]]],
                              "Mask2"->Table[{masks[[3]]},Length[result[[i,2]]]],
                              "Mask3"->Table[{masks[[4]]},Length[result[[i,2]]]],
                              "Mask4"->Table[{masks[[5]]},Length[result[[i,2]]]],
                              "Elevation"->Table[ele,Length[result[[i,1]]]]|>,TargetDevice->{"GPU",2}]},
    tempt=Map[Normal[#[[;;,1]]]&,Values[tempt]];
    tempt=Prepend[tempt,Normal[result[[i,3]][[;;,-1]]]];
    Map[NumericArray[Exp[#]-1.,"Real32"]&,tempt]];
   
pObser=Block[{start=Round[DateDifference[{1981,12,31},{testdates[[i,1]],10,1}]][[1]]},
  Map[NumericArray[#,"Real32"]&,{pR1[[start;;start+length-1]],
   pR2[[start;;start+length-1]],
   pR3[[start;;start+length-1]],
   pR4[[start;;start+length-1]],
   pR5[[start;;start+length-1]]}]];
Print[Map[Max,pObser]];
Print[Map[Max,pRaw]];
Print[Map[Max,pCorrection]];

Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/P/"<>DateString[testdates[[i]],{"Year","_","Month","_","Day","_","Hour",".mx"}],
  <|"pObser"->pObser,
    "pRaw"->pRaw,
    "pCorrection"->pCorrection|>]; ]],{i,Length[result],1,-1}];



tDownscaling=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/T_Downscaling.mx"];
Table[ToExpression["tR"<>ToString[i]<>"=Normal[Import[\"T_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];
meanvar=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Normalization.mx"]["meanvarT"];
tR1=Map[#*masks[[1]]&,tR1];
tR2=Map[#*masks[[2]]&,tR2];
tR3=Map[#*masks[[3]]&,tR3];
tR4=Map[#*masks[[4]]&,tR4];
tR5=Map[#*masks[[5]]&,tR5];

Table[
If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/T/"<>DateString[testdates[[i]],{"Year","_","Month","_","Day","_","Hour",".mx"}]]],
Block[{pRaw,pCorrection,pObser},
Print[testdates[[i]]];
tRaw=Block[{tempt=tDownscaling[<|"Input"->result[[i,2]],
                              "Mask1"->Table[{masks[[2]]},Length[result[[i,2]]]],
                              "Mask2"->Table[{masks[[3]]},Length[result[[i,2]]]],
                              "Mask3"->Table[{masks[[4]]},Length[result[[i,2]]]],
                              "Mask4"->Table[{masks[[5]]},Length[result[[i,2]]]],
                              "Elevation"->Table[ele,Length[result[[i,1]]]]|>,TargetDevice->{"GPU",2}]},
    tempt=Map[Normal[#[[;;,1]]]&,Values[tempt]];
    tempt=Prepend[tempt,Normal[result[[i,2]][[;;,-2]]]];
    tempt=Table[Map[((#*meanvar[[i,2]]+10^-7)+meanvar[[i,1]])*masks[[i]]&,tempt[[i]]],{i,Length[tempt]}];
    Map[NumericArray[#,"Real32"]&,tempt]];

tCorrection=Block[{tempt=tDownscaling[<|"Input"->result[[i,3]],
                              "Mask1"->Table[{masks[[2]]},Length[result[[i,2]]]],
                              "Mask2"->Table[{masks[[3]]},Length[result[[i,2]]]],
                              "Mask3"->Table[{masks[[4]]},Length[result[[i,2]]]],
                              "Mask4"->Table[{masks[[5]]},Length[result[[i,2]]]],
                              "Elevation"->Table[ele,Length[result[[i,1]]]]|>,TargetDevice->{"GPU",2}]},
    tempt=Map[Normal[#[[;;,1]]]&,Values[tempt]];
    tempt=Prepend[tempt,Normal[result[[i,3]][[;;,-2]]]];
    tempt=Table[Map[((#*meanvar[[i,2]]+10^-7)+meanvar[[i,1]])*masks[[i]]&,tempt[[i]]],{i,Length[tempt]}];
    Map[NumericArray[#,"Real32"]&,tempt]];

tObser=Block[{start=Round[DateDifference[{1981,12,31},{testdates[[i,1]],10,1}]][[1]]},
  Map[NumericArray[#,"Real32"]&,{tR1[[start;;start+length-1]],
   tR2[[start;;start+length-1]],
   tR3[[start;;start+length-1]],
   tR4[[start;;start+length-1]],
   tR5[[start;;start+length-1]]}]];

Print[Map[MinMax,Normal[tObser]]];
Print[Map[MinMax,Normal[tRaw]]];
Print[Map[MinMax,Normal[tCorrection]]];

Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/T/"<>DateString[testdates[[i]],{"Year","_","Month","_","Day","_","Hour",".mx"}],
  <|"tObser"->tObser,
    "tRaw"->tRaw,
    "tCorrection"->tCorrection|>]; ]],{i,RandomSample[Range[Length[result]]]}];



(*
group=Select[Table[Position[testdates[[;;,1]],testyear[[i]]][[;;,1]],{i,Length[testyear]}],Length[#]>0&];
gresult=Table[Block[{tempt=result[[group[[i]]]]},
 Table[Mean[Normal[tempt[[;;,j]]]],{j,4}]],{i,Length[group]}];

corrRaw=Table[Block[{obser=Map[Mean,Normal[gresult[[;;,1]][[;;,;;,var]]]],forecast=Map[Mean,Normal[gresult[[;;,2]][[;;,;;,var]]]]},
  Table[If[Variance[obser[[;;,i,j]]]>0,Correlation[obser[[;;,i,j]],forecast[[;;,i,j]]],-1],{i,16},{j,22}]],{var,2}];

corrCorrection=Table[Block[{obser=Map[Mean,Normal[gresult[[;;,1]][[;;,;;,var]]]],forecast=Map[Mean,Normal[gresult[[;;,4]][[;;,;;,var]]]]},
  Table[If[Variance[obser[[;;,i,j]]]>0,Correlation[obser[[;;,i,j]],forecast[[;;,i,j]]],-1],{i,16},{j,22}]],{var,2}];

Map[Mean[Select[Flatten[#],Positive]]&,corrRaw]
Map[Mean[Select[Flatten[#],Positive]]&,corrCorrection]


var=2;
Correlation[Map[Mean[Flatten[#]]&,Normal[result[[;;,1,;;,var]]]],Map[Mean[Flatten[#]]&,Normal[result[[;;,4,;;,var]]]]]
Correlation[Map[Mean[Flatten[#]]&,Normal[result[[;;,1,;;,var]]]],Map[Mean[Flatten[#]]&,Normal[result[[;;,2,;;,var]]]]]

Correlation[Map[Mean[Flatten[#]]&,Normal[gresult[[;;,1,;;,var]]]],Map[Mean[Flatten[#]]&,Normal[gresult[[;;,4,;;,var]]]]]
Correlation[Map[Mean[Flatten[#]]&,Normal[gresult[[;;,1,;;,var]]]],Map[Mean[Flatten[#]]&,Normal[gresult[[;;,2,;;,var]]]]]


tObser=Table[Mean[Flatten[Normal[result[[i,1,;;,1]]]]],{i,Length[result]}];
pObser=Table[Mean[Flatten[Normal[result[[i,1,;;,2]]]]],{i,Length[result]}];

tRaw=Table[Mean[Flatten[Normal[result[[i,2,;;,1]]]]],{i,Length[result]}];
pRaw=Table[Mean[Flatten[Normal[result[[i,2,;;,2]]]]],{i,Length[result]}];

tCorrection=Table[Mean[Flatten[Normal[result[[i,4,;;,1]]]]],{i,Length[result]}];
pCorrection=Table[Mean[Flatten[Normal[result[[i,4,;;,2]]]]],{i,Length[result]}];

Export["/usr/workspace/pan11/CycleGAN_HD/Result/mean.mx",
 <|"tObser"->tObser,
   "pObser"->pObser,
   "tRaw"->tRaw,
   "pRaw"->pRaw,
   "tCorrection"->tCorrection,
   "pCorrection"->pCorrection,
   "group"->group,
   "description"->"mean winter mean WUS precipitation/temperature forecast for 1982 to 2019"|>];

var=1;
Max[Normal[result[[;;,1,;;,var]]]]
Max[Normal[result[[;;,2,;;,var]]]]
Max[Normal[result[[;;,4,;;,var]]]]

a=Mean[Flatten[Normal[result[[;;,1,;;,var]]],1]];
b=Mean[Flatten[Normal[result[[;;,2,;;,var]]],1]];
c=Mean[Flatten[Normal[result[[;;,4,;;,var]]],1]];
Correlation[Flatten[a],Flatten[b]]
Correlation[Flatten[a],Flatten[c]]


Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/correction.mx",  
	<|"obser"->result[[;;,1]],    
	  "raw"->result[[;;,2]],    
          "correction"->result[[;;,3]]|>];


pDownscaling=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/P_Downscaling.mx"];
tDownscaling=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/t_Downscaling.mx"];

length=Length[result[[1,1]]];
rawinput=test[[i,1]][[2;;length+1]];
correctioninput=Block[{tempt=rawinput},
  

