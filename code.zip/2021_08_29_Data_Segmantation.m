SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Forecast"];
existing=Map[StringRiffle[StringSplit[#,{"N_","_",".mx"}],""]&,FileNames["*mx"]];
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/RawForecast"];
there=FileNames["*time*"];
Map[If[MemberQ[existing,StringSplit[#,"."][[2]]],DeleteFile[#]]&,there];
Map[If[MemberQ[existing,StringSplit[#,"."][[3]]],DeleteFile[#]]&,there];


SetDirectory["/usr/workspace/pan11/CycleGAN_HD/RawForecast"];
month="1984";
dates=DeleteDuplicates[Map[Select[StringSplit[#,"."],StringMatchQ[#,"*"<>month<>"*"]&][[1]]&,FileNames["*"<>month<>"*grb2"]]];
dates=RandomSample[dates];
variable={"prate","prmsl", "q925", "q850", "q500", "z1000", "z850", "tmp2m"};
example=Import["/usr/workspace/pan11/CycleGAN_HD/Forecast/N_1987_08_24_12.mx"];

 <<JLink`;InstallJava[];ReinstallJava[JVMArguments -> "-Xmx1460108m"];
Table[
If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/Forecast/N_"<>StringTake[dates[[j]],{1,4}]<>"_"<>StringTake[dates[[j]],{5,6}]<>"_"<>StringTake[dates[[j]],{7,8}]<>"_"<>StringTake[dates[[j]],{9,10}]<>".mx"]],
data=Table[Block[{tempt,lat,lon,position},
 <<JLink`;InstallJava[];ReinstallJava[JVMArguments -> "-Xmx1460108m"];
 tempt=Import[FileNames[variable[[i]]<>"*"<>dates[[j]]<>"*grb2"][[1]],{"Datasets",1}];
 DeleteFile[FileNames[variable[[i]]<>"*"<>dates[[j]]<>"*grb2.gbx8"][[1]]];
 lat=Import[FileNames[variable[[i]]<>"*"<>dates[[j]]<>"*grb2"][[1]],{"Datasets","lat"}];
 DeleteFile[FileNames[variable[[i]]<>"*"<>dates[[j]]<>"*grb2.gbx8"][[1]]];
 lon=Import[FileNames[variable[[i]]<>"*"<>dates[[j]]<>"*grb2"][[1]],{"Datasets","lon"}];
 DeleteFile[FileNames[variable[[i]]<>"*"<>dates[[j]]<>"*grb2.gbx8"][[1]]];
 position={{Position[lat,example[[i,"lat"]][[1]]][[1,1]],Position[lat,example[[i,"lat"]][[-1]]][[1,1]]},
           {Position[lon,example[[i,"lon"]][[1]]][[1,1]],Position[lon,example[[i,"lon"]][[-1]]][[1,1]]}};
 tempt=ArrayReshape[tempt,DeleteCases[Dimensions[tempt],1]][[;;,position[[1,1]];;position[[1,2]],position[[2,1]];;position[[2,2]]]];
 Print[Dimensions[tempt]];
 <|"data"->NumericArray[tempt,"Real32"],
   "date"->dates[[j]],
   "lat"->lat[[position[[1,1]];;position[[1,2]]]],
   "lon"->lon[[position[[2,1]];;position[[2,2]]]],
   "var"->variable[[i]]|>],{i,Length[variable]}];
Export["/usr/workspace/pan11/CycleGAN_HD/Forecast/N_"<>StringTake[dates[[j]],{1,4}]<>"_"<>StringTake[dates[[j]],{5,6}]<>"_"<>StringTake[dates[[j]],{7,8}]<>"_"<>StringTake[dates[[j]],{9,10}]<>".mx",data]],{j,Length[dates]}];
