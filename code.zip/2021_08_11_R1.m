Import["/g/g92/pan11/CycleGAN_HD/2021_08_07_Regularization_Keep.m"];
ReleaseHold[choice7];
