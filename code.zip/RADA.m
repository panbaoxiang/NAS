vars={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
channel=Length[mask];
day=Dimensions[mask][[2]];
dim=Dimensions[mask];
dime=Dimensions[dem];

contract[channel_,crop_:{{1,1},{1,1}}]:=NetGraph[{"conv"->{ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                                                           ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp},
                                   "pooling"->PoolingLayer[{1,2,2},{1,2,2},{0,1,1}],
                                   "cropping"->PartLayer[{;;,crop[[1,1]];;-crop[[1,-1]],crop[[2,1]];;-crop[[2,-1]]}]},
                         {NetPort["Input"]->"conv"->"pooling"->NetPort["Pooling"],"conv"->"cropping"->NetPort["Shortcut"]}]

ResizeLayer3D[n_, {dimInx_, dimIny_, dimInz_}] :=Block[{sc = 2},
  NetChain[{
    FlattenLayer[1, "Input" -> {n sc, dimInx, dimIny, dimInz}],
    ResizeLayer[{Scaled[sc], Scaled[sc]}],
    ReshapeLayer[{n sc, dimInx, sc dimIny, sc dimInz}],
    TransposeLayer[2 <-> 3],
    FlattenLayer[1],
    ResizeLayer[{Scaled[sc], Scaled[1]}],
    ReshapeLayer[{n sc, sc dimIny, sc dimInx, sc dimInz}],
    TransposeLayer[2 <-> 3],
    ConvolutionLayer[n, 1]}
   ]]

ClearAll[expand];
expand[channel_,{dimInx_, dimIny_, dimInz_},pad_:{1,1,1},RAMP_:1]:=NetGraph[
                {"deconv"->{ResizeLayer3D[channel,{dimInx,dimIny,dimInz}],BatchNormalizationLayer[],Ramp,PartLayer[{;;,pad[[1]];;-2,pad[[2]];;-2,pad[[3]];;-2}]},
         "join"->CatenateLayer[],
         "conv"->If[RAMP==1,
                 {ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                  ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp},
                 {ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
                  ConvolutionLayer[channel,{3,3,3},"Stride"->1,"PaddingSize"->1],BatchNormalizationLayer[]}]},
        {NetPort["Input"]->"deconv"->"join",NetPort["Shortcut"]->"join"->"conv"}]

Unet=NetInitialize[NetGraph[<|
  "contract_1"->contract[16],
  "contract_2"->contract[32],
  "contract_3"->contract[64],
  "contract_4"->contract[128],
  "ubase"->{ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,ConvolutionLayer[128,{3,3,3},PaddingSize->1],Ramp,DropoutLayer[0.5]},
  "expand_4"->expand[64,{3,2,3},{3,1,2}],
  "expand_3"->expand[32,{3,3,4},{3,1,1}],
  "expand_2"->expand[16,{3,5,7},{3,1,2}],
  "expand_1"->expand[8,{3,9,12},{3,2,2},0]|>,
  {NetPort["Input"]->"contract_1",
   NetPort["contract_1","Pooling"]->"contract_2",
   NetPort["contract_2","Pooling"]->"contract_3",
   NetPort["contract_3","Pooling"]->"contract_4",
   NetPort["contract_4","Pooling"]->"ubase",
   "ubase"->NetPort["expand_4","Input"],
   NetPort["contract_4","Shortcut"]->NetPort["expand_4","Shortcut"],
   NetPort["expand_4","Output"]->NetPort["expand_3","Input"],
   NetPort["contract_3","Shortcut"]->NetPort["expand_3","Shortcut"],
   NetPort["expand_3","Output"]->NetPort["expand_2","Input"],
   NetPort["contract_2","Shortcut"]->NetPort["expand_2","Shortcut"],
    NetPort["expand_2","Output"]->NetPort["expand_1","Input"],
   NetPort["contract_1","Shortcut"]->NetPort["expand_1","Shortcut"]},
   "Input"->Prepend[dim[[2;;]], dime[[1]]+dim[[1]]]]];

S2O=NetInitialize[NetGraph[Flatten[Prepend[{"u"->Unet,"blend"->CatenateLayer[],"cate"->CatenateLayer[],"thread"->ThreadingLayer[Times],"postPart1"->PartLayer[1;;7],"postPart2"->{PartLayer[-1;;-1],Ramp},"c"->CatenateLayer[]},
	Table[{"part"<>ToString[i]->PartLayer[i;;i],"cat"<>ToString[i]->CatenateLayer[],
           "post"<>ToString[i]->If[i<7,
                                {ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1},"Weights"->0,"Biases"->0],BatchNormalizationLayer[],Ramp,
                                ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1},"Weights"->0,"Biases"->0],BatchNormalizationLayer[],Ramp,
                                ConvolutionLayer[1,{3,3,3},"PaddingSize"->{1,1,1},"Weights"->0,"Biases"->0], BatchNormalizationLayer[]},
                                {ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1}],BatchNormalizationLayer[],Ramp,
                                ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1}],BatchNormalizationLayer[],Ramp,
                                ConvolutionLayer[1,{3,3,3},"PaddingSize"->{1,1,1}], BatchNormalizationLayer[]}],
           "thread"<>ToString[i]->ThreadingLayer[Plus]},{i,8}]]],
Flatten[Append[{NetPort["GCM"]->"blend",NetPort["DEM"]->"blend"->"u",NetPort["Mask"]->"thread"->NetPort["Obser"],"cate"->"postPart1"->"c","cate"->"postPart2"->"c"->"thread"},
Table[{"u"->"cat"<>ToString[i],NetPort["GCM"]->"part"<>ToString[i]->"cat"<>ToString[i]->"post"<>ToString[i]->"thread"<>ToString[i],"part"<>ToString[i]->"thread"<>ToString[i]->"cate"},{i,8}]]],
 "GCM"->dim,
 "DEM"->dime,
 "Mask"->dim]];

O2S=NetInitialize[NetGraph[Flatten[Prepend[{"u"->Unet,"blend"->CatenateLayer[],"cate"->CatenateLayer[],"thread"->ThreadingLayer[Times],"postPart1"->PartLayer[1;;7],"postPart2"->{PartLayer[-1;;-1],Ramp},"c"->CatenateLayer[]},
	Table[{"part"<>ToString[i]->PartLayer[i;;i],"cat"<>ToString[i]->CatenateLayer[],
           "post"<>ToString[i]->If[i<7,
                                {ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1},"Weights"->0,"Biases"->0],BatchNormalizationLayer[],Ramp,
                                ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1},"Weights"->0,"Biases"->0],BatchNormalizationLayer[],Ramp,
                                ConvolutionLayer[1,{3,3,3},"PaddingSize"->{1,1,1},"Weights"->0,"Biases"->0], BatchNormalizationLayer[]},
                                {ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1}],BatchNormalizationLayer[],Ramp,
                                ConvolutionLayer[16,{3,3,3},"PaddingSize"->{1,1,1}],BatchNormalizationLayer[],Ramp,
                                ConvolutionLayer[1,{3,3,3},"PaddingSize"->{1,1,1}], BatchNormalizationLayer[]}],
           "thread"<>ToString[i]->ThreadingLayer[Plus]},{i,8}]]],
Flatten[Append[{NetPort["Obser"]->"blend",NetPort["DEM"]->"blend"->"u",NetPort["Mask"]->"thread"->NetPort["GCM"],"cate"->"postPart1"->"c","cate"->"postPart2"->"c"->"thread"},
Table[{"u"->"cat"<>ToString[i],NetPort["Obser"]->"part"<>ToString[i]->"cat"<>ToString[i]->"post"<>ToString[i]->"thread"<>ToString[i],"part"<>ToString[i]->"thread"<>ToString[i]->"cate"},{i,8}]]],
 "Obser"->dim,
 "DEM"->dime,
 "Mask"->dim]];


SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Result/Regularization"];
{pRS,pRSmse}=Values[Import["trained_p_simulation_regularization.mx"]];
{pRO,pROmse}=Values[Import["trained_p_observation_regularization.mx"]];
{tRS,tRSmse}=Values[Import["trained_t_simulation_regularization.mx"]];
{tRO,tROmse}=Values[Import["trained_t_observation_regularization.mx"]];
{yesterdayRS,yesterdayRSmse}=Values[Import["trained_tomorrow_simulation_regularization.mx"]];
{yesterdayRO,yesterdayROmse}=Values[Import["trained_tomorrow_observation_regularization.mx"]];
{tomorrowRS,tomorrowRSmse}=Values[Import["trained_yesterday_simulation_regularization.mx"]];
{tomorrowRO,tomorrowROmse}=Values[Import["trained_yesterday_observation_regularization.mx"]];


dis=NetChain[{ConvolutionLayer[16,{3,3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   FlattenLayer[1],
			   ConvolutionLayer[16,{3,3},"Stride"->2],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   FlattenLayer[],
			   1,
			   ElementwiseLayer["HardSigmoid"]
			   },
	"Input"->dim];
DS2O=NetGraph[<|"dis"->{NetMapOperator[dis],FlattenLayer[],ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0]},
				"fake"->PartLayer[1],
				"real"->PartLayer[2]|>,
	{NetPort["Input"]->"dis"->"fake"->NetPort["Fake_S2O"],"dis"->"real"->NetPort["Real_S2O"]},
	"Input"->Prepend[dim,2]];
DO2S=NetGraph[<|"dis"->{NetMapOperator[dis],FlattenLayer[],ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0]},
				"fake"->PartLayer[1],
				"real"->PartLayer[2]|>,
	{NetPort["Input"]->"dis"->"fake"->NetPort["Fake_O2S"],"dis"->"real"->NetPort["Real_O2S"]},
	"Input"->Prepend[dim,2]];

ldis=NetChain[{ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3},"Stride"->2],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   Ramp,
			   ConvolutionLayer[16,{3,3}],
			   BatchNormalizationLayer[],
			   FlattenLayer[],
			   1,
			   ElementwiseLayer["HardSigmoid"]
			   },
	"Input"->dim[[2;;]]];

Dvar[var_,dir_]:=NetGraph[<|"part"->PartLayer[{;;,var}],
				       "dis"->{NetMapOperator[ldis],FlattenLayer[],ConstantTimesLayer["Scaling" -> {-1, 1},LearningRateMultipliers->0]},
				       "fake"->PartLayer[1],
				       "real"->PartLayer[2]|>,
	{NetPort["Input"]->"part"->"dis",
	"dis"->"fake"->NetPort["Fake_"<>dir<>"_"<>vars[[var]]],
	"dis"->"real"->NetPort["Real_"<>dir<>"_"<>vars[[var]]]},
	"Input"->Prepend[dim,2]]

S2Of = NetInsertSharedArrays[S2O, "S2O/"];
S2Ob = NetInsertSharedArrays[S2O, "S2O/"];
S2Os = NetInsertSharedArrays[S2O, "S2O/"];

O2Sf = NetInsertSharedArrays[O2S, "O2S/"];
O2Sb = NetInsertSharedArrays[O2S, "O2S/"];
O2Ss = NetInsertSharedArrays[O2S, "O2S/"];

RADA=NetInitialize[NetGraph[<|
		   "S2Of"->S2Of,
		   "O2Sf"->O2Sf,
		   
		   "Cat_S2O"->CatenateLayer[],
                   "Reshape_S2O" -> ReshapeLayer[Prepend[dim,2]],
                   "DS2O" -> DS2O,
           
                   "Cat_O2S"->CatenateLayer[],
                   "Reshape_O2S" -> ReshapeLayer[Prepend[dim,2]],
                   "DO2S"->DO2S,
		   
		   "O2Sb"->O2Sb,
		   "S2Ob"->S2Ob,
		   "MSE_S2O2S"->MeanAbsoluteLossLayer[],
		   "MSE_O2S2O"->MeanAbsoluteLossLayer[],
		  
		   "pR_S"->{pRS,ElementwiseLayer[Max[#,pRSmse]-pRSmse &]},
		   "pR_O"->{pRO,ElementwiseLayer[Max[#,pROmse]-pROmse &]},
		   "tR_S"->{tRS,ElementwiseLayer[Max[#,tRSmse]-tRSmse &]},
		   "tR_O"->{tRO,ElementwiseLayer[Max[#,tROmse]-tROmse &]},
		   "yesterdayR_S"->{yesterdayRS,ElementwiseLayer[Max[#,yesterdayRSmse]-yesterdayRSmse &]},
		   "yesterdayR_O"->{yesterdayRO,ElementwiseLayer[Max[#,yesterdayROmse]-yesterdayROmse &]},
		   "tomorrowR_S"->{tomorrowRS,ElementwiseLayer[Max[#,tomorrowRSmse]-tomorrowRSmse &]},
		   "tomorrowR_O"->{tomorrowRO,ElementwiseLayer[Max[#,tomorrowROmse]-tomorrowROmse &]},
		
		   
		   "S2Os"->S2Os,
		   "O2Ss"->O2Ss,
		   "MSE_S2Os"->MeanAbsoluteLossLayer[],
		   "MSE_O2Ss"->MeanAbsoluteLossLayer[],
		   
		   (*{"prmsl","q925","q850","q500","z1000","z850","t2m","p"}*)
		   "DS2Oprmsl"->Dvar[1,"S2O"],
		   "DO2Sprmsl"->Dvar[1,"O2S"],
		   
		   "DS2Oq925"->Dvar[2,"S2O"],
		   "DO2Sq925"->Dvar[2,"O2S"],
		   
		   "DS2Oz1000"->Dvar[5,"S2O"],
		   "DO2Sz1000"->Dvar[5,"O2S"],
		   
		   "DS2Ot2m"->Dvar[7,"S2O"],
		   "DO2St2m"->Dvar[7,"O2S"],
		   
		   "DS2Op"->Dvar[8,"S2O"],
		   "DO2Sp"->Dvar[8,"O2S"]
		   |>,
 {NetPort["S"]->NetPort["S2Of","GCM"],
  NetPort["Elevation"]->NetPort["S2Of","DEM"],
  NetPort["Mask"]->NetPort["S2Of","Mask"],
  "S2Of"->"Cat_S2O",
  NetPort["O"]->"Cat_S2O",
  "Cat_S2O"->"Reshape_S2O"->"DS2O",
  
  NetPort["O"]->NetPort["O2Sf","Obser"],
  NetPort["Mask"]->NetPort["O2Sf","Mask"],
  NetPort["Elevation"]->NetPort["O2Sf","DEM"],
  "O2Sf"->"Cat_O2S",
  NetPort["S"]->"Cat_O2S",
  "Cat_O2S"->"Reshape_O2S"->"DO2S",
  
  "S2Of"->NetPort["O2Sb","Obser"],
  NetPort["Mask"]->NetPort["O2Sb","Mask"],
  NetPort["Elevation"]->NetPort["O2Sb","DEM"],
  "O2Sb"->"MSE_S2O2S",
  NetPort["S"]->"MSE_S2O2S"->NetPort["Cycle_S2O"],
  
  "O2Sf"->NetPort["S2Ob","GCM"],
  NetPort["Mask"]->NetPort["S2Ob","Mask"],
  NetPort["Elevation"]->NetPort["S2Ob","DEM"],
  "S2Ob"->"MSE_O2S2O",
  NetPort["O"]->"MSE_O2S2O"->NetPort["Cycle_O2S"],
  
  
  
  "S2Of"->NetPort["pR_O","Input"],
  NetPort["Mask"]->NetPort["pR_O","Mask"],
  NetPort["Elevation"]->NetPort["pR_O","Elevation"],
  "pR_O"->NetPort["Loss_pR_O"],
  
  "S2Of"->NetPort["tR_O","Input"],
  NetPort["Mask"]->NetPort["tR_O","Mask"],
  NetPort["Elevation"]->NetPort["tR_O","Elevation"],
  "tR_O"->NetPort["Loss_tR_O"],
  
  "S2Of"->NetPort["yesterdayR_O","Input"],
  NetPort["Mask"]->NetPort["yesterdayR_O","Mask"],
  NetPort["Elevation"]->NetPort["yesterdayR_O","Elevation"],
  "yesterdayR_O"->NetPort["Loss_yesterdayR_O"],
  
  "S2Of"->NetPort["tomorrowR_O","Input"],
  NetPort["Mask"]->NetPort["tomorrowR_O","Mask"],
  NetPort["Elevation"]->NetPort["tomorrowR_O","Elevation"],
  "tomorrowR_O"->NetPort["Loss_tomorrowR_O"],
  
  "O2Sf"->NetPort["pR_S","Input"],
  NetPort["Mask"]->NetPort["pR_S","Mask"],
  NetPort["Elevation"]->NetPort["pR_S","Elevation"],
  "pR_S"->NetPort["Loss_pR_S"],
  
  "O2Sf"->NetPort["tR_S","Input"],
  NetPort["Mask"]->NetPort["tR_S","Mask"],
  NetPort["Elevation"]->NetPort["tR_S","Elevation"],
  "tR_S"->NetPort["Loss_tR_S"],
  
  "O2Sf"->NetPort["yesterdayR_S","Input"],
  NetPort["Mask"]->NetPort["yesterdayR_S","Mask"],
  NetPort["Elevation"]->NetPort["yesterdayR_S","Elevation"],
  "yesterdayR_S"->NetPort["Loss_yesterdayR_S"],
  
  "O2Sf"->NetPort["tomorrowR_S","Input"],
  NetPort["Mask"]->NetPort["tomorrowR_S","Mask"],
  NetPort["Elevation"]->NetPort["tomorrowR_S","Elevation"],
  "tomorrowR_S"->NetPort["Loss_tomorrowR_S"],
  
  NetPort["O"]->NetPort["S2Os","GCM"],
  NetPort["Mask"]->NetPort["S2Os","Mask"],
  NetPort["Elevation"]->NetPort["S2Os","DEM"],
  "S2Os"->"MSE_S2Os",
  NetPort["O"]->"MSE_S2Os"->NetPort["Loss_Self_S2O"],
 
  NetPort["S"]->NetPort["O2Ss","Obser"],
  NetPort["Mask"]->NetPort["O2Ss","Mask"],
  NetPort["Elevation"]->NetPort["O2Ss","DEM"],
  "O2Ss"->"MSE_O2Ss",
  NetPort["S"]->"MSE_O2Ss"->NetPort["Loss_Self_O2S"],
  
  "Reshape_S2O"->"DS2Oprmsl",
  "Reshape_O2S"->"DO2Sprmsl",
  
  "Reshape_S2O"->"DS2Oq925",
  "Reshape_O2S"->"DO2Sq925",
  
  "Reshape_S2O"->"DS2Oz1000",
  "Reshape_O2S"->"DO2Sz1000",
  
  "Reshape_S2O"->"DS2Ot2m",
  "Reshape_O2S"->"DO2St2m",
  
  "Reshape_S2O"->"DS2Op",
  "Reshape_O2S"->"DO2Sp"
  }]]
