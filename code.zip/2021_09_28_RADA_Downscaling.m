{s1,s2,s3,s4,s5}={4,4,4,10,2};
Print[{s1,s2,s3,s4,s5}];
vars={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
dem=NumericArray[{Log[Import["Elevation.mx"][[1]]+1.]},"Real32"];(*{368, 493}, 4km*4km*)
training=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/training.mx"][[;;,{1,3}]];
validation=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/validation.mx"][[;;,{1,3}]];
test=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/test.mx"][[;;,{1,3}]];
mask=Block[{tempt=Variance[Normal[training[[1,1,-1]]]]},
  NumericArray[Table[If[And[c>6,tempt[[i,j]]==0.],0,1],{c,8},{d,3},{i,Length[tempt]},{j,Dimensions[tempt][[2]]}],"Real32"]];

validation=Join[validation,test];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Paired"];
alldates=Table[FileNames[ToString[year]<>"*mx"],{year,1982,2016}];
trainingdates=Flatten[alldates[[1;;9]]];
validationdates=Flatten[alldates[[10;;]]];

position=Flatten[Table[Quiet[Position[validationdates,_?(StringMatchQ[#,ToString[year]<>"_07*mx"]&)][[;;,1]]],{year,1991,2016}]];
july=Table[Block[{start,tstartend},
 start=ToExpression[StringSplit[validationdates[[position[[i]]]],{"_","."}][[1;;3]]];
 tstartend={DateDifference[start,{start[[1]],10,1}][[1]],DateDifference[start,{start[[1]]+1,3,31}][[1]]};
 Print[{validationdates[[position[[i]]]],start,tstartend}];
 Map[#[[;;,tstartend[[1]];;tstartend[[2]]]]&,validation[[position[[i]]]]]],{i,Length[position]}];
Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/July.mx",
 <|"data"->july,
   "dates"->validationdates[[position]]|>];


models=Map[NetTake[Import[#],"S2Of"]&,FileNames["/usr/workspace/pan11/CycleGAN_HD/Result/RADA/RADA_July_*mx"]];
result=Block[{correction,raw,obser,mcorrection,mraw,mobser},
 correction=Table[Print[{k,j}];models[[k]][<|"S"->july[[;;,1,;;,j;;j+2]],"Elevation"->Table[dem,Length[july]],"Mask"->Table[mask,Length[july]]|>,TargetDevice->{"GPU",If[k<=2,1,2]}][[;;,;;,2]],{k,Length[models]},{j,180}];
 raw=Table[july[[;;,1,;;,j;;j+2]][[;;,;;,2]],{j,180}];
 obser=Table[july[[;;,2,;;,j;;j+2]][[;;,;;,2]],{j,180}];
 {correction,raw,obser}];

mcorrection=Mean[Mean[Normal[result[[1]]]]];
mraw=Mean[Normal[result[[2]]]];
mobser=Mean[Normal[result[[3]]]];

corrCorrection=Table[If[Variance[mcorrection[[;;,var,i,j]]]>0,Correlation[mcorrection[[;;,var,i,j]],mobser[[;;,var,i,j]]],-1],{var,7,8},{i,16},{j,22}];
corrRaw=Table[If[Variance[mcorrection[[;;,var,i,j]]]>0,Correlation[mraw[[;;,var,i,j]],mobser[[;;,var,i,j]]],-1],{var,7,8},{i,16},{j,22}];
Map[Mean[Select[Flatten[#],#>-1&]]&,corrCorrection]
Map[Mean[Select[Flatten[#],#>-1&]]&,corrRaw]

rmseCorrection=Table[Mean[(mcorrection[[;;,var,i,j]]-mobser[[;;,var,i,j]])^2],{var,7,8},{i,16},{j,22}];
rmseRaw=Table[Mean[(mraw[[;;,var,i,j]]-mobser[[;;,var,i,j]])^2],{var,7,8},{i,16},{j,22}];
{Mean[Flatten[rmseCorrection]],Mean[Flatten[rmseRaw]]}

nposition=Block[{dates=validationdates[[position]]},
  Select[Table[Quiet[Position[dates,_?(StringMatchQ[#,ToString[year]<>"*mx"]&)]][[;;,1]],{year,1991,2016}],Length[#]>0&]];

nmcorrection=Table[Mean[mcorrection[[nposition[[i]]]]],{i,Length[nposition]}];
nmraw=Table[Mean[mraw[[nposition[[i]]]]],{i,Length[nposition]}];
nmobser=Table[Mean[mobser[[nposition[[i]]]]],{i,Length[nposition]}];
years=Range[25];
ncorrCorrection=Table[If[Variance[nmcorrection[[years,var,i,j]]]>0,Correlation[nmcorrection[[years,var,i,j]],nmobser[[years,var,i,j]]],-1],{var,7,8},{i,16},{j,22}];
ncorrRaw=Table[If[Variance[nmcorrection[[years,var,i,j]]]>0,Correlation[nmraw[[years,var,i,j]],nmobser[[years,var,i,j]]],-1],{var,7,8},{i,16},{j,22}];
Map[Mean[Select[Flatten[#],#>-1&]]&,ncorrCorrection]
Map[Mean[Select[Flatten[#],#>-1&]]&,ncorrRaw]

nrmseCorrection=Table[Mean[(nmcorrection[[years,var,i,j]]-nmobser[[years,var,i,j]])^2],{var,7,8},{i,16},{j,22}];
nrmseRaw=Table[Mean[(nmraw[[years,var,i,j]]-nmobser[[years,var,i,j]])^2],{var,7,8},{i,16},{j,22}];
Table[{Mean[Flatten[nrmseCorrection[[i]]]],Mean[Flatten[nrmseRaw[[i]]]]},{i,2}]


(*downscaling*)
result=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/result.mx"];
correction=NumericArray[Mean[Normal[result[[1]]]],"Real32"];
raw=NumericArray[Normal[result[[2]]],"Real32"];
obser=NumericArray[Normal[result[[3]]],"Real32"];
dates=Map[ToExpression[StringSplit[#,{"_","."}][[1;;4]]]&,dates];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
masks=Map[NumericArray[{#},"Real32"]&,Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Downscaling_Masks.mx"]];
Table[ToExpression["pR"<>ToString[i]<>"=Map[#*Normal[masks[["<>ToString[i]<>"]][[1]]]&,Normal[Import[\"P_R"<>ToString[i]<>".mx\"][\"data\"]]];"],{i,5}];
Table[ToExpression["tR"<>ToString[i]<>"=Map[#*Normal[masks[["<>ToString[i]<>"]][[1]]]&,Normal[Import[\"T_R"<>ToString[i]<>".mx\"][\"data\"]]];"],{i,5}];
meanvar=Block[{data={tR1,tR2,tR3,tR4,tR5}},
 Table[Block[{mean,var,tempt},
  mean=Mean[data[[i]]];
  var=Sqrt[Variance[data[[i]]]];
  {mean*Normal[masks[[i,1]]],(var+10^-6)*Normal[masks[[i,1]]]}],{i,5}]];

Pnet=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/P_Downscaling.mx"];
Tnet=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling/T_Downscaling.mx"];

Table[
If[Not[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/"<>DateString[dates[[member]],{"Year","_","Month","_","Day","_","Hour",".mx"}]]],
Block[{hPraw,hPcorrection,hPobser,hTraw,hTcorrection,hTobser},
Print[dates[[member]]];
hPcorrection=Block[{all},
 all=Table[Block[{hcorrection},
  	hcorrection=Block[{tempt},
	tempt=Pnet[<|"Input"->correction[[i*30+1;;(i+1)*30,member]],
		   "Mask1"->Table[masks[[2]],30],
		   "Mask2"->Table[masks[[3]],30],
		   "Mask3"->Table[masks[[4]],30],
		   "Mask4"->Table[masks[[5]],30],
		   "Elevation"->Table[dem,30]|>,TargetDevice->{"GPU",2}];
       Table[NumericArray[Exp[Normal[tempt[[j,;;,1]]]]-1.,"Real32"],{j,4}]]],{i,0,5}];
  Prepend[Table[all[[;;,j]]/.List->Join,{j,4}],NumericArray[Exp[Normal[correction[[;;,member,-1]]]]-1.,"Real32"]]];

hPraw=Block[{all},
 all=Table[Block[{hraw},
        hraw=Block[{tempt},
        tempt=Pnet[<|"Input"->raw[[i*30+1;;(i+1)*30,member]],
                   "Mask1"->Table[masks[[2]],30],
                   "Mask2"->Table[masks[[3]],30],
                   "Mask3"->Table[masks[[4]],30],
                   "Mask4"->Table[masks[[5]],30],
                   "Elevation"->Table[dem,30]|>,TargetDevice->{"GPU",2}];
       Table[NumericArray[Exp[Normal[tempt[[j,;;,1]]]]-1.,"Real32"],{j,4}]]],{i,0,5}];
  Prepend[Table[all[[;;,j]]/.List->Join,{j,4}],NumericArray[Exp[Normal[raw[[;;,member,-1]]]]-1.,"Real32"]]];

hPobser=Block[{start=DateDifference[{1981,12,31},{dates[[member]][[1]],10,2}][[1]]},
 Map[NumericArray[#,"Real32"]&,{pR1[[start;;start+179]],pR2[[start;;start+179]],pR3[[start;;start+179]],pR4[[start;;start+179]],pR5[[start;;start+179]]}]];

Print[Table[{Correlation[Flatten[Mean[Normal[hPraw[[res]]]]],Flatten[Mean[Normal[hPobser[[res]]]]]],Correlation[Flatten[Mean[Normal[hPcorrection[[res]]]]],Flatten[Mean[Normal[hPobser[[res]]]]]]},{res,5}]];

hTcorrection=Block[{all,all2},
 all=Table[Block[{hcorrection},
        hcorrection=Block[{tempt},
        tempt=Tnet[<|"Input"->correction[[i*30+1;;(i+1)*30,member]][[;;,Append[Range[7],7]]],
                   "Mask1"->Table[masks[[2]],30],
                   "Mask2"->Table[masks[[3]],30],
                   "Mask3"->Table[masks[[4]],30],
                   "Mask4"->Table[masks[[5]],30],
                   "Elevation"->Table[dem,30]|>,TargetDevice->{"GPU",2}];
       Table[NumericArray[Normal[tempt[[j,;;,1]]],"Real32"],{j,4}]]],{i,0,5}];
 all2=Prepend[Table[all[[;;,j]]/.List->Join,{j,4}],correction[[;;,member,-2]]];
 Table[NumericArray[Map[#*meanvar[[i,2]]+meanvar[[i,1]]&,Normal[all2[[i]]]],"Real32"],{i,Length[meanvar]}]];

hTraw=Block[{all,all2},
 all=Table[Block[{hraw},
        hraw=Block[{tempt},
        tempt=Tnet[<|"Input"->raw[[i*30+1;;(i+1)*30,member]][[;;,Append[Range[7],7]]],
                   "Mask1"->Table[masks[[2]],30],
                   "Mask2"->Table[masks[[3]],30],
                   "Mask3"->Table[masks[[4]],30],
                   "Mask4"->Table[masks[[5]],30],
                   "Elevation"->Table[dem,30]|>,TargetDevice->{"GPU",2}];
       Table[NumericArray[Normal[tempt[[j,;;,1]]],"Real32"],{j,4}]]],{i,0,5}];
 all2=Prepend[Table[all[[;;,j]]/.List->Join,{j,4}],raw[[;;,member,-2]]];
 Table[NumericArray[Map[#*meanvar[[i,2]]+meanvar[[i,1]]&,Normal[all2[[i]]]],"Real32"],{i,Length[meanvar]}]];

hTobser=Block[{start=DateDifference[{1981,12,31},{dates[[member]][[1]],10,2}][[1]]},
 Map[NumericArray[#,"Real32"]&,{tR1[[start;;start+179]],tR2[[start;;start+179]],tR3[[start;;start+179]],tR4[[start;;start+179]],tR5[[start;;start+179]]}]];

Print[Table[{Correlation[Flatten[Mean[Normal[hTraw[[res]]]]],Flatten[Mean[Normal[hTobser[[res]]]]]],Correlation[Flatten[Mean[Normal[hTcorrection[[res]]]]],Flatten[Mean[Normal[hTobser[[res]]]]]]},{res,5}]];

Export["/usr/workspace/pan11/CycleGAN_HD/Result/Verification/Output/"<>DateString[dates[[member]],{"Year","_","Month","_","Day","_","Hour",".mx"}],
  <|"hPraw"->hPraw,
    "hPcorrection"->hPcorrection,
    "hPobser"->hPobser,
    "hTraw"->hTraw,
    "hTcorrection"->hTcorrection,
    "hTobser"->hTobser|>];]],{member,RandomSample[Range[Length[dates]]]}];
