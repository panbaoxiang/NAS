test=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/test.mx"];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
Table[ToExpression["pR"<>ToString[i]<>"=Normal[Import[\"P_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];

Table[ToExpression["tR"<>ToString[i]<>"=Normal[Import[\"T_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];

masks=Table[Block[{mp=Mean[Normal[ToExpression["pR"<>ToString[ii]]]],position},
  position=Table[If[mp[[i,j]]>0,1,0],{i,Length[mp]},{j,Dimensions[mp][[2]]}];
  position],{ii,5}];

ele=Block[{tempt=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Elevation.mx"]["Elevation"]},
 tempt=(tempt /. x_ /; x<-0.->0);
 {Log[tempt+1.]}];

lead=1;
forecast = Table[<|"Input"->Normal[test[[i,1,;;,lead]]],
   "Mask1"->{masks[[2]]},
   "Mask2"->{masks[[3]]},
   "Mask3"->{masks[[4]]},
   "Mask4"->{masks[[5]]},
   "Elevation"->ele|>,{i,Length[test]}];
obser = Table[<|"Input"->Normal[test[[i,3,;;,lead]]],
   "Mask1"->{masks[[2]]},
   "Mask2"->{masks[[3]]},
   "Mask3"->{masks[[4]]},
   "Mask4"->{masks[[5]]},
   "Elevation"->ele|>,{i,Length[test]}];

net=Import["/usr/workspace/pan11/CycleGAN_HD/Result/P_Downscaling.mx"];

forecastresult=Exp[Map[net[#,TargetDevice->"GPU"]&,forecast]]-1.;
obserresult=Exp[Map[net[#,TargetDevice->"GPU"]&,obser]]-1.;
  
forecastresult=Table[Prepend[forecastresult[[i]],"Output_R0"->Normal[{test[[i,1,-1,lead]]}]],{i,Length[forecast]}];
obserresult=Table[Prepend[obserresult[[i]],"Output_R0"->Normal[{test[[i,3,-1,lead]]}]],{i,Length[forecast]}];

corr=Table[Block[{s=forecastresult[[;;,"Output_R"<>ToString[i]]],o=obserresult[[;;,"Output_R"<>ToString[i]]]},
   Table[If[Or[Variance[o[[;;,1,a,b]]]==0,Variance[s[[;;,1,a,b]]]==0],-1,Correlation[s[[;;,1,a,b]],o[[;;,1,a,b]]]],{a,Dimensions[s][[3]]},{b,Dimensions[s][[4]]}]],{i,0,4}];

Export["/g/g92/pan11/corr.mx",corr];


net=Import["/usr/workspace/pan11/CycleGAN_HD/Result/T_Downscaling.mx"];

forecastresult=Map[net[#,TargetDevice->"GPU"]&,forecast];
obserresult=Map[net[#,TargetDevice->"GPU"]&,obser];

forecastresult=Table[Prepend[forecastresult[[i]],"Output_R0"->Normal[{test[[i,1,-2,lead]]}]],{i,Length[forecast]}];
obserresult=Table[Prepend[obserresult[[i]],"Output_R0"->Normal[{test[[i,3,-2,lead]]}]],{i,Length[forecast]}];

corr=Table[Block[{s=forecastresult[[;;,"Output_R"<>ToString[i]]],o=obserresult[[;;,"Output_R"<>ToString[i]]]},
   Table[If[Or[Variance[o[[;;,1,a,b]]]==0,Variance[s[[;;,1,a,b]]]==0],-1,Correlation[s[[;;,1,a,b]],o[[;;,1,a,b]]]],{a,Dimensions[s][[3]]},{b,Dimensions[s][[4]]}]],{i,0,4}];

Export["/g/g92/pan11/corrT.mx",corr];
