var={"prmsl", "q925", "q850", "q500", "z1000", "z850", "t2m","p"};
SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData"];
testdate=Block[{tempt=Flatten[Table[FileNames["Paired/"<>ToString[year]<>"*mx"],{year,1997,2016}]]},
  Map[StringSplit[#,{"Paired/",".mx"}][[1]]&,tempt]];
dem=NumericArray[{Log[Import["Elevation.mx"][[1]]+1.]},"Real32"];(*{368, 493}, 4km*4km*)
validation=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/validation.mx"][[;;,{1,3}]];
test=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/test.mx"][[;;,{1,3}]];
mask=Block[{tempt=Variance[Normal[validation[[1,1,-1]]]]},
  NumericArray[Table[If[And[c>6,tempt[[i,j]]==0.],0,1],{c,8},{d,3},{i,Length[tempt]},{j,Dimensions[tempt][[2]]}],"Real32"]];
Import["/g/g92/pan11/CycleGAN_HD/RADA_Final.m"];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/Result"];
indexes=Map[StringSplit[#,{"_",".mx"}][[-1]]&,FileNames["*RADA_new*mx"]];
nets=Map[Import["trained_RADA_new_"<>#<>".mx"]&,indexes];

choice1=Range[Length[test]];
choice2=Range[8,14];
data=Table[<|"S"->test[[choice1[[i]],1]][[;;,j;;j+2]],
             "O"->test[[choice1[[i]],2]][[;;,j;;j+2]],
             "Elevation"->dem,
             "Mask"->mask|>,{i,choice1},{j,choice2}];

corrections=Normal[Table[Block[{model},
{correction,obser,raw}=Map[Normal,{correction,obser,raw}];
  model=NetTake[nets[[k]],"S2Of"];
  Print[k];
  Table[model[<|"S"->data[[i,j]][["S"]],"Elevation"->data[[1,1]][["Elevation"]],"Mask"->data[[1,1]][["Mask"]]|>,TargetDevice->"GPU"],
   {i,Length[choice1]},{j,Length[choice2]}]],{k,Length[nets]}]];
correction=Map[Mean,Mean[corrections]];
obser=Normal[Mean[Table[data[[;;,i,"O"]],{i,Length[choice2]}]]];
raw=Normal[Mean[Table[data[[;;,i,"S"]],{i,Length[choice2]}]]];


(*Climatology*)
corr1=Table[Correlation[Flatten[Mean[correction[[;;,var,2]]]],Flatten[Mean[obser[[;;,var,2]]]]],{var,8}];
corr2=Table[Correlation[Flatten[Mean[raw[[;;,var,2]]]],Flatten[Mean[obser[[;;,var,2]]]]],{var,8}];
Print[TableForm[{corr1,corr2}]];

(*Forecast*)
corr1=Table[If[Variance[Flatten[obser[[;;,var,2,i,j]]]]>0,Correlation[Flatten[correction[[;;,var,2,i,j]]],Flatten[obser[[;;,var,2,i,j]]]],0],{var,8},{i,16},{j,22}];
corr2=Table[If[Variance[Flatten[obser[[;;,var,2,i,j]]]]>0,Correlation[Flatten[raw[[;;,var,2,i,j]]],Flatten[obser[[;;,var,2,i,j]]]],0],{var,8},{i,16},{j,22}];
Print[TableForm[Map[Map[Mean[Select[Flatten[#],Positive]]&,#]&,{corr1,corr2}]]];


month=7;
division=Table[Select[testdate,StringMatchQ[#,DateString[DateObject[{year,month,1}],{"Year","_","Month","_"}]<>"*"]&],{year,1997,2016}];

result=Table[If[Length[division[[year]]]>0,
Block[{raw,obser,correction},
Print[year+1996];
{raw,obser}=Block[{position=Map[DateDifference[ToExpression[StringSplit[division[[year,1]],"_"]],#][[1]]&,{{year+1996,10,1},{year+1997,3,31}}]},
  Table[test[[Position[testdate,division[[year,1]]][[1,1]]]][[ii]][[;;,position[[1]];;position[[2]]]],{ii,2}]];
correction=Table[Block[{position=Map[DateDifference[ToExpression[StringSplit[division[[year,j]],"_"]][[1;;3]],#][[1]]&,{{year+1996,9,30},{year+1997,4,1}}],correction},
  If[Dimensions[test[[Position[testdate,division[[year,j]]][[1,1]]]][[1]]][[2]]>=position[[2]],
  S=test[[Position[testdate,division[[year,j]]][[1,1]]]][[1]][[;;,position[[1]];;position[[2]]]];
  model=NetTake[net,"S2Of"];
  Print[j];
  correction=NumericArray[Transpose[Normal[Table[model[<|"S"->S[[;;,i;;i+2]],"Elevation"->dem, "Mask"->mask|>,TargetDevice->"GPU"][[;;,1]],{i,Dimensions[S][[2]]-2}]]],"Real32"],
  Null]],{j,Length[division[[year]]]}];
correction=Select[correction,Head[#]==NumericArray&];
{raw,obser,correction}],{Null,Null,Null}],{year,Length[division]}];

Export["/g/g92/pan11/result.mx",result]
