obser=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation/obser.mx"]["data"];
ele=Block[{tempt=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Elevation.mx"]["Elevation"]},
 tempt=(tempt /. x_ /; x<-0.->0);
 NumericArray[{Log[tempt+1.]},"Real32"]];
masks=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Mask.mx"];

SetDirectory["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Observation"];
Table[ToExpression["pR"<>ToString[i]<>"=Normal[Import[\"P_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,1}];
Table[ToExpression["pR"<>ToString[i]<>"=(Log[Map[#*masks[[i]]&,pR"<>ToString[i]<>"]+1.]);"],{i,1}];
Table[ToExpression["tR"<>ToString[i]<>"=Normal[Import[\"T_R"<>ToString[i]<>".mx\"][\"data\"]];"],{i,5}];
{tR1,tR2,tR3,tR4,tR5}=Block[{meanvar},
  meanvar=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Normalization.mx"]["meanvarT"];
  Table[Print[i];Map[(#-meanvar[[i,1]])/(meanvar[[i,2]]+10^-7)*masks[[i]]&,ToExpression["tR"<>ToString[i]]],{i,5}]];
Print[Map[MinMax,{tR1,tR2,tR3,tR4,tR5}]];

data=Block[{meanvar,tempt,p},
 meanvar=Import["/usr/workspace/pan11/CycleGAN_HD/ProcessedData/Support/Normalization.mx"]["meanvarobser"];
 tempt=Table[Map[(#-meanvar[[i,1]])/(meanvar[[i,2]]+10^-7)&,Normal[obser[[;;,i]]]],{i,7}];
 tempt=Transpose[Join[tempt,{pR1}]];
 Table[<|"Input"->tempt[[i]],
         "Output_R1"->{tR2[[i]]},
         "Output_R2"->{tR3[[i]]},
         "Output_R3"->{tR4[[i]]},
         "Output_R4"->{tR5[[i]]}|>,{i,Length[tempt]}]];


DH={1,368,493};
NNele=NetChain[{ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		ConvolutionLayer[8,{7,7}],BatchNormalizationLayer[],Ramp,PoolingLayer[2,2],
		ConvolutionLayer[2,{2,4}],BatchNormalizationLayer[]},
 "Input"->DH];

deconv[channel_,scale_:2]:={DeconvolutionLayer[channel,{scale,scale},"Stride"->scale],BatchNormalizationLayer[],Ramp,
 ConvolutionLayer[channel,{3,3},"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
 ConvolutionLayer[channel,{3,3},"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
 ConvolutionLayer[channel,{3,3},"PaddingSize"->1],BatchNormalizationLayer[],Ramp};

output={ConvolutionLayer[16,{3,3},"PaddingSize"->1],BatchNormalizationLayer[],Ramp,
	    ConvolutionLayer[1,{2,2}],BatchNormalizationLayer[]};

SD=NetGraph[<|"combine"->CatenateLayer[],
			   "ele"->NNele,
			   "deconv1"->deconv[16,2],
			   "output1"->output,
			   "mask1"->ThreadingLayer[Times],
			   "deconv2"->deconv[16,2],
			   "output2"->{output,PartLayer[{All,2;;62,3;;84}]},
			   "mask2"->ThreadingLayer[Times],
			   "deconv3"->deconv[16,3],
			   "output3"->{output,PartLayer[{All,4;;187,9;;254}]},
			   "mask3"->ThreadingLayer[Times],
			   "deconv4"->deconv[16,2],
			   "output4"->{output,PartLayer[{All,8;;367+8,17;;492+17}]},
			   "mask4"->ThreadingLayer[Times]|>,
	{NetPort["Input"]->"combine",
	 NetPort["Elevation"]->"ele"->"combine",
	 "combine"->"deconv1"->"output1"->"mask1",NetPort["Mask1"]->"mask1"->NetPort["Output_R1"],
	 "deconv1"->"deconv2",
	 "deconv2"->"output2"->"mask2",NetPort["Mask2"]->"mask2"->NetPort["Output_R2"],
	 "deconv2"->"deconv3",
	 "deconv3"->"output3"->"mask3",NetPort["Mask3"]->"mask3"->NetPort["Output_R3"],
	 "deconv3"->"deconv4",
	 "deconv4"->"output4"->"mask4",NetPort["Mask4"]->"mask4"->NetPort["Output_R4"]},
 "Input"->{8,16,22}];

seq=Import["/usr/workspace/pan11/CycleGAN_HD/Result/Downscaling_seq.mx"];
data=data[[seq]];
training=Range[Round[Length[data]*0.75]];
validation=Range[Round[Length[data]*0.75],Round[Length[data]*0.85]];
test=Range[Round[Length[data]*0.85],Length[data]];
valiset= Table[<|"Input"->data[[i,"Input"]],
   "Mask1"->{masks[[2]]},
   "Output_R1"->data[[i,"Output_R1"]],
   "Mask2"->{masks[[3]]},
   "Output_R2"->data[[i,"Output_R2"]],
   "Mask3"->{masks[[4]]},
   "Output_R3"->data[[i,"Output_R3"]],
   "Mask4"->{masks[[5]]},
   "Output_R4"->data[[i,"Output_R4"]],
   "Elevation"->ele|>,{i,validation}];

globe=0.025;
Report[net_]:=Block[{simu,corr,mse},
  simu=Normal[Values[Map[net[#,TargetDevice->"GPU"]&,valiset[[;;,{"Input","Mask1","Mask2","Mask3","Mask4","Elevation"}]]]]];
  obser=Normal[Values[valiset[[;;,{"Output_R1","Output_R2","Output_R3","Output_R4"}]]]];
  summary=Table[Mean[Flatten[(simu[[;;,i]]-obser[[;;,i]])^2]],{i,4}];
  Print[summary];
  Print[Total[summary]];
  If[Total[summary]<globe,
     Block[{},
       Print["Update"];
       Export["/usr/workspace/pan11/CycleGAN_HD/Result/T_Downscaling.mx",net];
       Set[globe,Total[summary]]]]];

SD=If[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/Result/T_Downscaling.mx"],
  Import["/usr/workspace/pan11/CycleGAN_HD/Result/T_Downscaling.mx"],SD];
lr=If[FileExistsQ["/usr/workspace/pan11/CycleGAN_HD/Result/P_Downscaling.mx"],10^-4,10^-3];

NetTrain[SD,
 {Function[Block[{choice},
  choice=RandomSample[training,#BatchSize];
 <|"Input"->data[[choice]][[;;,"Input"]],
   "Mask1"->Table[{masks[[2]]},#BatchSize],
   "Output_R1"->data[[choice]][[;;,"Output_R1"]],
   "Mask2"->Table[{masks[[3]]},#BatchSize],
   "Output_R2"->data[[choice]][[;;,"Output_R2"]],
   "Mask3"->Table[{masks[[4]]},#BatchSize],
   "Output_R3"->data[[choice]][[;;,"Output_R3"]],
   "Mask4"->Table[{masks[[5]]},#BatchSize],
   "Output_R4"->data[[choice]][[;;,"Output_R4"]],
   "Elevation"->Table[ele,#BatchSize]|>]],"RoundLength"->Length[training]},
 ValidationSet->valiset,
 BatchSize->64,
 TargetDevice->{"GPU",All},
  MaxTrainingRounds->400,
  Method -> {"ADAM", "Beta1" -> 0.5, "LearningRate" -> lr},
 TrainingProgressReporting -> {{Function@Report[#Net], "Interval" -> Quantity[1, "Rounds"]},"Print"}];

